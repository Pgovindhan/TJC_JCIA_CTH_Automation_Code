﻿using System;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EAppGeneralTestAutomation.Utilities;
using System.IO;
using System.Diagnostics;
using System.Threading;
using TikaOnDotNet.TextExtraction;
using System.Windows.Forms;
using System.Collections;
using System.Configuration;
using Microsoft.Win32;
using OpenQA.Selenium.Edge;
using System.Net.Mail;

namespace EAppGeneralTestAutomation.Operations
{
    public class SeleniumActions
    {
        public static IWebDriver driver = null;

        public static string ClickTab_NextLink;
        public static string ClickTab_TabToDisplay;

        public static string ColumnSortBtn;
        private static int m_PreviousZoomFactor = 0;
        private static int currentZoomFactor;
        public static string HCO_ID;
        public static Hashtable tokens = new Hashtable();
        public static Hashtable StoredDetails = new Hashtable();

        /* ______________Invoking the web drivers_____________________
        /**********************************************
               Function : InvokeBrowser
               Function Desc: Opens desire browser
               I/P args: Null 
               Return Value: void
               Precondition: All browers should be closed for better automation
               Author: Vincent 
        ************************************************ */
        public static IWebDriver InvokeBrowser(string testMethodName, string module, string browser, string url)
        {
            string BrowserFlag = "WindowsAuth";
            string exMsg = string.Empty;

            try
            {
                switch (browser.ToUpper().Trim())
                {
                    case "IE":
                    case "INTERNET EXPLORER":
                    case "IEXPLORER":
                        System.Threading.Thread.Sleep(2000);

                        if (BrowserFlag == "MSAuth_TJC")
                        {
                            if (driver == null)
                            {
                                var options = new InternetExplorerOptions();
                                options.EnsureCleanSession = true;
                                options.BrowserCommandLineArguments = "-private";
                                driver = new InternetExplorerDriver(options);
                                driver.Manage().Window.Maximize();
                                driver.Navigate().GoToUrl(url);
                                Assert.IsNotNull(driver);
                            }
                            else
                            {
                                driver.Manage().Window.Maximize();
                                driver.Navigate().GoToUrl(url);
                            }
                        }

                        if (BrowserFlag == "WindowsAuth")
                        {
                            var options = new InternetExplorerOptions();
                            options.EnsureCleanSession = true;
                            options.BrowserCommandLineArguments = "-private";
                            driver = new InternetExplorerDriver(options);
                            driver.Manage().Window.Maximize();
                            driver.Navigate().GoToUrl(url);
                            Assert.IsNotNull(driver);
                        }

                        break;

                    case "CHROME":
                    case "Chrome":
                    case "chrome":


                        ChromeOptions GCoptions = new ChromeOptions();
                        GCoptions.AddArgument("incognito");
                        GCoptions.AddArgument("test-type");
                        GCoptions.AddArgument("--start-maximized");
                        // Initialize the Chrome Driver
                        driver = new ChromeDriver(GCoptions);
                        driver.Navigate().GoToUrl(url);
                        driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

                        break;

                    case "MOZILLA":
                    case "FIREFOX":
                        Console.WriteLine(Directory.GetCurrentDirectory());// + "\\Debug");
                        FirefoxDriverService service = FirefoxDriverService.CreateDefaultService(Directory.GetCurrentDirectory());// + "\\Debug");
                        service.FirefoxBinaryPath = @"C:\Program Files (x86)\Mozilla Firefox\firefox.exe";
                        driver = new FirefoxDriver(service);
                        driver.Navigate().GoToUrl(url);
                        break;

                    default:
                        {
                            var options1 = new InternetExplorerOptions();
                            options1.EnsureCleanSession = true;
                            driver = new InternetExplorerDriver(options1);
                            driver.Manage().Window.Maximize();
                            driver.Navigate().GoToUrl(url);
                            Assert.IsNotNull(driver);
                        }
                        break;
                }

            }
            catch (Exception ex)
            {
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
                TestLogic.Flag++;
            }
            return driver;
        }

        /* ______________Launching the desire browser_____________________*/
        public static void InvokeBrowser(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                switch (browser.ToUpper())
                {
                    case "IE":
                    case "INTERNET EXPLORER":
                    case "IEXPLORER":

                        var options = new InternetExplorerOptions();
                        options.EnsureCleanSession = true;
                        options.BrowserCommandLineArguments = "-private";
                        options.EnsureCleanSession = true;
                        options.IgnoreZoomLevel = true;
                        //driver.Manage().Cookies.DeleteAllCookies();
                        driver = new InternetExplorerDriver(options);
                        driver.Manage().Window.Maximize();
                        driver.Navigate().GoToUrl(TestData);
                        SetZoom100();
                        Console.WriteLine("Zoom " + currentZoomFactor);

                        break;

                    case "CHROME":
                    case "GOOGLE CHROME":
                    case "GOOGLECHROME":



                        string chromepath = ConfigurationManager.AppSettings["chromepath"];

                        if (string.IsNullOrEmpty(chromepath))
                        {
                            ChromeOptions GCoptions = new ChromeOptions();

                            //GCoptions.AddUserProfilePreference("download.default_directory", downloadDirectory);
                            GCoptions.AddUserProfilePreference("download.prompt_for_download", false);
                            GCoptions.AddUserProfilePreference("disable-popup-blocking", "true");

                            GCoptions.AddArgument("test-type");
                            GCoptions.AddArgument("--start-maximized");
                            GCoptions.AddArgument("--window-size=1920,1080");
                            //GCoptions.AddArgument("headless");
                            // Initialize the Chrome Driver
                            driver = new ChromeDriver(GCoptions);
                            driver.Navigate().GoToUrl(TestData);
                            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
                            Thread.Sleep(15000);
                        }
                        else
                        {
                            //driver = new ChromeDriver("C:\\TJC\\MS Monthly Patch Testing\\Patch Testing Scripts\\TJC\\UAT\\ACOSTDTestAutomation\\");
                            ChromeOptions GCoptions = new ChromeOptions();

                            //GCoptions.AddUserProfilePreference("download.default_directory", downloadDirectory);
                            GCoptions.AddUserProfilePreference("download.prompt_for_download", false);
                            GCoptions.AddUserProfilePreference("disable-popup-blocking", "true");

                            GCoptions.AddArgument("test-type");
                            GCoptions.AddArgument("--start-maximized");
                            GCoptions.AddArgument("--window-size=1920,1080");
                            //GCoptions.AddArgument("headless");
                            driver = new ChromeDriver(chromepath, GCoptions);
                            driver.Navigate().GoToUrl(TestData);
                            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
                            Thread.Sleep(2000);
                        }
                        break;

                    case "EDGE":

                    case "EDGEO":
                    case "EDGEF":


                        var eo2 = new EdgeOptions();
                        // eo2.AddArgument("headless");
                        //eo2.AddAdditionalCapability("disable-popup-blocking", true);
                        driver = new EdgeDriver("C:\\TJC\\MS Monthly Patch Testing\\CommonDriver\\", eo2);


                        //string serverPath = System.Environment.ExpandEnvironmentVariables("C:\\Users\\GovindhP\\Downloads\\edgedriver_win32");
                        //driver = new EdgeDriver("C:\\Users\\GovindhP\\Downloads\\edgedriver_win64\\msedgedriver.exe");
                        //driver = new OpenQA.Selenium.Edge.EdgeDriver();
                        driver.Manage().Window.Maximize();

                        driver.Manage().Window.Maximize();
                        driver.Navigate().GoToUrl(TestData);
                        Thread.Sleep(5000);

                        break;

                    default:
                        Reports.Report_TestDataStep(driver, TestStepID, "'" + browser + "' does not exist in the list, please provide valid browser name", Keyword, ObjectName, TestData, "Fail", RunningTestCase);
                        break;
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }

        /* ______________Navigate Browser To Specific URL_____________________*/
        public static void NavigateTo(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                driver.Navigate().GoToUrl(TestData);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the Browser for complete loading of the URL_____________________*/
        public static void Browser_Verification(string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var brow = driver.FindElement(By.XPath(xpath), 10);

            if (brow.Text == xpath_verification)
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData, "Pass", RunningTestCase);

            else
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData, "Fail", RunningTestCase);

        }

        /* ______________Taking Screenshots in case of error_____________________*/
        public Screenshot CaptureImages()
        {
            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            return ss;
        }

        /* ______________Clicking on the Web Element_____________________*/
        public static void Click_on(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElement(By.XPath(xpath));
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0];", ele);
                CommonFunctions.highlight(driver, ele);
                text = ele.Text;
                ele.Click();

                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        public static void JSClick_on(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            String exMsg = "";

            String FlagTestCase = "Pass";

            try
            {
                System.Threading.Thread.Sleep(1000);
                IWebElement ele = null;
                ele = driver.FindElement(By.XPath(xpath));
                Actions action = new Actions(driver);
                action.MoveToElement(ele);
                action.Build();
                action.Perform();
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", ele);

                if (ele == null)
                {
                    if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                    {
                        HybridLogic.bProceedOnFail = false;
                    }
                    FlagTestCase = "Fail";
                    TestLogic.TestFail++;
                    exMsg = "Element is not present in the DOM";
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, "" + "\n" + exMsg, FlagTestCase, RunningTestCase);

            }
        }

        public static void Send_Email(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            String exMsg = "";

            String FlagTestCase = "Pass";

            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("jcsendmail.jcaho.net");
                mail.From = new MailAddress("Entapptesting@jointcommission.org");
                //mail.To.Add(new MailAddress("PGovindhan@jointcommission.org"));
                mail.To.Add("Entapptesting@jointcommission.org");
                //mail.To.Add("PGovindhan@jointcommission.org");
                //mail.CC.Add(Short_Fall);
                mail.CC.Add("PGovindhan@jointcommission.org");
                mail.Bcc.Add("PGovindhan@jointcommission.org");
                //mail.CC.Add(new MailAddress("PGovindhan@jointcommission.org"));
                //mail.Bcc.Add(new MailAddress("PGovindhan@jointcommission.org"));
                //mail.CC.Add(new MailAddress("CC recipient", "PGovindhan@jointcommission.org"));
                //mail.Bcc.Add(new MailAddress("CC recipient", "PGovindhan@jointcommission.org"));

                mail.Subject = "EAPPGeneral Performance Testing";
                mail.Body = "EAPPGeneral Performance Testing";
                //mail.Body = "Test case" + testcase;
                mail.Body = "EAPPGeneral Performance Testing";

                mail.IsBodyHtml = true;
                mail.Attachments.Add(new Attachment(@"C:\TJC\MS Monthly Patch Testing\Performance Testing Scripts\UAT\EApp_General1\TestReport\Chrome.html"));
                //mail.Attachments.Add(new Attachment(@"C:\Users\GovindhP\Documents\Visual Studio 2015\Projects\SAM_IDE_Flow\NUnitTestProject1\TestReport\dashboard.html"));
                //SmtpServer.SendMailAsync(mail);
                SmtpServer.Send(mail);

                Console.WriteLine("Send Email Successfully.........");

            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "PASS";
                //TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, "" + "\n" + exMsg, FlagTestCase, RunningTestCase);

            }
        }

        public static void JSClick_on_Test(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            String exMsg = "";

            String FlagTestCase = "Pass";

            try
            {
                System.Threading.Thread.Sleep(1000);
                IWebElement ele = null;

                ele = driver.FindElement(By.XPath(xpath));
                Actions action = new Actions(driver);
                action.MoveToElement(ele);
                ele.Clear();
                ele.SendKeys("337843");
                ele.SendKeys(OpenQA.Selenium.Keys.Tab);

            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "PASS";
                //TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, "" + "\n" + exMsg, FlagTestCase, RunningTestCase);

            }
        }



        /* ______________Clicking on the HCO Tab - Created for IE Browser_____________________*/
        public static void Click_HCO(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);
                CommonFunctions.highlight(driver, ele);
                text = ele.Text;

                if (browser.Trim().ToUpper() == "IE" || browser.Trim().ToUpper() == "INTERNET EXPLORER" || browser.Trim().ToUpper() == "IEXPLORER")
                {
                    bool clicked = false;
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();
                    while (!clicked && stopwatch.Elapsed < TimeSpan.FromSeconds(100))
                    {
                        Actions act = new Actions(driver);
                        act.MoveToElement(ele).Perform();
                        System.Threading.Thread.Sleep(2000);
                        act.Click(ele).Perform();
                        try
                        {
                            string check = driver.FindElement(By.XPath(".//span[contains(text(),'" + HCO_ID + "')]/..")).Text;
                            clicked = true;
                        }
                        catch
                        {

                        }
                    }
                }
                else
                {
                    ele.Click();
                }

                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the Web Element_____________________*/
        public static void Start_Test(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                using (TextWriter rb = File.AppendText(@"C:\TJC\MS Monthly Patch Testing\Performance Testing Scripts\UAT\EApp_General1\TestReport\Chrome.html"))
                {
                    String TestData_StartTime = DateTime.Now.ToString();
                    rb.WriteLine("<tr>");
                    rb.WriteLine("<td width=30% align=center><FONT COLOR=#153E7E FACE=Arial SIZE=2><b>" + "" + "</b></td>");  //DetailedReport_filename
                    rb.WriteLine("<td width=25% align=center><FONT COLOR=#153E7E FACE=Arial SIZE=2><b>" + "" + "</b></td>");
               
                    rb.WriteLine("</tr>");
                    rb.WriteLine("<tr>");
                    rb.WriteLine("<td width=30% align=center><FONT COLOR=#153E7E FACE=Arial SIZE=2><b>" + "EAPPGeneral_Testing" + "</b></td>");  //DetailedReport_filename
                    rb.WriteLine("<td width=25% align=center><FONT COLOR=#153E7E FACE=Arial SIZE=2><b>" +"Start Time" +  TestData_StartTime + "</b></td>");
              
                    rb.WriteLine("</tr>");
                    rb.Close();
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the Web Element_____________________*/
        public static void Stop_Test(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                using (TextWriter rb = File.AppendText(@"C:\TJC\MS Monthly Patch Testing\Performance Testing Scripts\UAT\EApp_General1\TestReport\Chrome.html"))
                {
                    String TestData_StartTime = DateTime.Now.ToString();

                    rb.WriteLine("<tr>");
                    rb.WriteLine("<td width=30% align=center><FONT COLOR=#153E7E FACE=Arial SIZE=2><b>" + "EAPPGeneral_Testing" + "</b></td>");  //DetailedReport_filename
                    rb.WriteLine("<td width=25% align=center><FONT COLOR=#153E7E FACE=Arial SIZE=2><b>" + "Stop Time" + TestData_StartTime + "</b></td>");

                    rb.WriteLine("</tr>");
                    rb.Close();
                 }
                }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }
        /* ______________Clicking on the Header Tab - Logic is mainly created for IE Browser. In this method, the Tab mentioned will be clicked and then it's repective header section is made visible and then the 'next' link(Ex: General Application) will be clicked in the displayed section._____________________*/
        public static void Click_Tab(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);
                CommonFunctions.highlight(driver, ele);
                text = ele.Text;

                if (browser.Trim().ToUpper() == "EDGE" || browser.Trim().ToUpper() == "GOOGLE CHROME" || browser.Trim().ToUpper() == "GOOGLECHROME")
                {

                    ele.Click();
                    System.Threading.Thread.Sleep(3000);
                    driver.FindElement(By.XPath(ClickTab_NextLink)).Click();
                }
                else
                {
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();
                    int windowsCount = driver.WindowHandles.Count;

                    Actions act = new Actions(driver);

                    var jsDriver = (IJavaScriptExecutor)driver;
                    string highlightJavascript = "document.getElementById('" + ClickTab_TabToDisplay + "').style.display = 'block';";

                    try
                    {
                        var ele2 = driver.FindElement(By.XPath(ClickTab_NextLink));

                        act.MoveToElement(ele2).Perform();
                        System.Threading.Thread.Sleep(3000);
                        jsDriver.ExecuteScript(highlightJavascript);

                        ele2.Click();

                        System.Threading.Thread.Sleep(3000);
                        if (browser.Trim().ToUpper() == "IE" || browser.Trim().ToUpper() == "INTERNET EXPLORER" || browser.Trim().ToUpper() == "IEXPLORER")
                        {
                            jsDriver.ExecuteScript(highlightJavascript);
                            ele2.Click();

                            System.Threading.Thread.Sleep(3000);
                            driver.Close();
                            System.Threading.Thread.Sleep(3000);
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Mouse Over the Header Tab - Logic is mainly created for IE Browser. In this method, the Mouse Hover the Tab mentioned  then it's repective header section is made visible and then the 'next' link(Ex: General Application) will be clicked in the displayed section._____________________*/
        public static void Click_Tab2(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);
                CommonFunctions.highlight(driver, ele);
                text = ele.Text;

                if (browser.Trim().ToUpper() == "EDGE" || browser.Trim().ToUpper() == "GOOGLE CHROME" || browser.Trim().ToUpper() == "GOOGLECHROME")
                {
                    //ele.Click();
                    //System.Threading.Thread.Sleep(3000);
                    Actions action = new Actions(driver);
                    action.MoveToElement(ele).Perform();
                    driver.FindElement(By.XPath(ClickTab_NextLink)).Click();
                }
                else
                {
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();
                    int windowsCount = driver.WindowHandles.Count;

                    Actions act = new Actions(driver);

                    var jsDriver = (IJavaScriptExecutor)driver;
                    string highlightJavascript = "document.getElementById('" + ClickTab_TabToDisplay + "').style.display = 'block';";

                    try
                    {
                        act.MoveToElement(ele).Perform();
                        Thread.Sleep(3000);
                        jsDriver.ExecuteScript(highlightJavascript);
                        Thread.Sleep(2000);
                        var ele2 = driver.FindElement(By.XPath(ClickTab_NextLink));
                        ele2.Click();


                        Thread.Sleep(3000);
                        if (browser.Trim().ToUpper() == "IE" || browser.Trim().ToUpper() == "INTERNET EXPLORER" || browser.Trim().ToUpper() == "IEXPLORER")
                        {
                            jsDriver.ExecuteScript(highlightJavascript);
                            ele2.Click();

                            System.Threading.Thread.Sleep(3000);
                            jsDriver.ExecuteScript(highlightJavascript);
                            ele2.Click();

                            System.Threading.Thread.Sleep(3000);
                            driver.Close();
                            System.Threading.Thread.Sleep(3000);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
            catch (Exception ex)
            {
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Getting the Text from a Web Element_____________________*/
        public static void Get_Text(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string gettext_text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var gettext = driver.FindElement(By.XPath(xpath), 5);
                gettext_text = gettext.Text;
                Assert.IsNotNull(gettext);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }


        }

        /* ______________Hovering the Cursor on the Web Element_____________________*/
        public static void Mouse_Hover(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var element = driver.FindElement(By.XPath(xpath), 5);
                Actions action = new Actions(driver);
                action.MoveToElement(element).Perform();

                Assert.IsNotNull(element);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Waiting the browser for specific time_____________________*/
        public static void Wait_For(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                int waitFor = Convert.ToInt32(TestData);
                /*if (browser.Trim().ToUpper() == "CHROME" || browser.Trim().ToUpper() == "GOOGLE CHROME" || browser.Trim().ToUpper() == "GOOGLECHROME")
                {
                    waitFor = (waitFor * Int32.Parse(Reports.ChromeWaitPercentage)) / 100;
                    TestData = waitFor.ToString();
                }
                else*/ if (browser.Trim().ToUpper() == "MOZILLA" || browser.Trim().ToUpper() == "MOZILLAFIREFOX" || browser.Trim().ToUpper() == "FIREFOX")
                {
                    waitFor = (waitFor * Int32.Parse(Reports.FirefoxWaitPercentage)) / 100;
                    TestData = waitFor.ToString();
                }
                System.Threading.Thread.Sleep(waitFor);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Waiting the browser for specific time - Equally for all the Browsers_____________________*/
        public static void Wait_ForEqually(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                int waitFor = Convert.ToInt32(TestData);
                System.Threading.Thread.Sleep(waitFor);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Selecting the Value in the List by Text_____________________*/
        public static void Select_value(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);
                var selectElement = new SelectElement(ele);

                // select by text in a dropdownlist
                selectElement.SelectByText(TestData);
                Assert.IsNotNull(selectElement);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the Value of Web Element_____________________*/
        public static void verification_value(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                var elements = driver.FindElements(By.XPath(xpath));

                foreach (IWebElement element in elements)
                {
                    if (element.Text.Trim().Contains(TestData) || element.GetAttribute("value").Trim().Contains(TestData) || element.GetAttribute("innerHTML").Trim().Contains(TestData))
                    {
                        flag = "pass";
                        break;
                    }
                }

                Assert.AreSame("pass", flag, TestData + " - Text is not found in the " + ObjectName + " object");
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying Web Element is present in the page or not_____________________*/
        public static void Verify_Element(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                IWebElement element = driver.FindElement(By.XPath(xpath), 5);

                Assert.IsNotNull(element);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the Value of Web Element is not equal to Empty_____________________*/
        public static void Verification_NotEmpty(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                var elements = driver.FindElements(By.XPath(xpath));

                foreach (IWebElement element in elements)
                {
                    
                    if (!element.Text.Trim().Equals(string.Empty) || !element.GetAttribute("value").Trim().Equals(string.Empty))
                    {
                        flag = "pass";
                        break;
                    }
                }

                Assert.AreSame("pass", flag, ObjectName + " - Object doesn't contain any text");
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the list of Web Elements_____________________*/
        public static void verification_list(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                var tr_collection1 = driver.FindElements(By.XPath(xpath));

                foreach (IWebElement row in tr_collection1)
                {
                    if (row.Text.Contains(TestData))
                    {
                        flag = "pass";
                    }
                    else
                    {
                        flag = "fail";
                        break;
                    }
                }

                Assert.AreSame("pass", flag, TestData + " - Text is not found in the " + ObjectName + " object");
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the validation in the page. If validation is present, Test will fail_____________________*/
        public static void verification_NoValidation(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                IWebElement ele = driver.FindElement(By.XPath(xpath));
                //if element is present, then test is failed else passed
                FlagTestCase = "Fail";

                TestLogic.TestFail++;

                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }

                exMsg = "The validation is found in the page, thus Test Step " + TestStepID + " has failed";
            }
            catch
            {
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the Value of PDF_____________________*/
        public static void verification_PDF(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                string pdfContent, saveFile = string.Empty;

                if (browser.Trim().ToUpper() == "IE" || browser.Trim().ToUpper() == "INTERNET EXPLORER" || browser.Trim().ToUpper() == "IEXPLORER")
                {
                    saveFile = CommonFunctions.SaveAction_IE("PDFVerify");
                    Thread.Sleep(3000);
                }
                else
                {
                    saveFile = CommonFunctions.SaveAction("PDFVerify");
                    Thread.Sleep(1000);
                }

                TextExtractor textExtractor = new TextExtractor();
                pdfContent = textExtractor.Extract(saveFile).Text;

                if (!pdfContent.Contains(TestData))
                {
                    FlagTestCase = "Fail";
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Storing the Value of Web Element_____________________*/
        public static void Store_Details(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);

                text = ele.Text;

                if (text == string.Empty)
                {
                    text = ele.GetAttribute("value");
                }

                StoredDetails[TestData] = text;
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, text + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the Stored Value_____________________*/
        public static void VerifyStored_Details(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string text = "";
            string chkText = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);

                text = ele.Text;

                if (text == string.Empty)
                {
                    text = ele.GetAttribute("value");
                }

                chkText = StoredDetails[TestData].ToString().Trim();

                if (text.Contains(" January ") || text.Contains(" February ") || text.Contains(" March ") || text.Contains(" April ")
                 || text.Contains(" June ") || text.Contains(" July ") || text.Contains(" August ") || text.Contains(" September ")
                 || text.Contains(" October ") || text.Contains(" November ") || text.Contains(" December "))
                {
                    chkText = StoredDetails[TestData].ToString().Trim()
                            .Replace(" Jan ", " January ")
                            .Replace(" Feb ", " February ")
                            .Replace(" Mar ", " March ")
                            .Replace(" Apr ", " April ")
                            .Replace(" Jun ", " June ")
                            .Replace(" Jul ", " July ")
                            .Replace(" Aug ", " August ")
                            .Replace(" Sep ", " September ")
                            .Replace(" Oct ", " October ")
                            .Replace(" Nov ", " November ")
                            .Replace(" Dec ", " December ");
                }
                
                if (chkText != text.Trim())
                {
                    FlagTestCase = "Fail";
                }

                Assert.AreEqual("Pass", FlagTestCase, ObjectName + " - object does not contain the text '" + chkText + "' instead it is having '" + text + "'");
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "").Replace("Assert.AreEqual failed. Expected:. Actual:. ", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, chkText + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Entering the Value in Textbox_____________________*/
        public static void Enter_Value(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);
                ele.Click();
                ele.Clear();
                //ele.SendKeys(TestData);
                IWebElement wb = driver.FindElement(By.XPath(xpath));
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                //js.ExecuteScript("arguments[0].value='TestData';", wb);
                js.ExecuteScript("arguments[0].value='" + TestData + "';", wb);

                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Entering the Value in Textbox_____________________*/
        public static void Enter_Value_JS(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);
                ele.Click();
                ele.Clear();
                ele.SendKeys(TestData);
                IWebElement wb = driver.FindElement(By.XPath(xpath));
                /*IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                //js.ExecuteScript("arguments[0].value='TestData';", wb);
                js.ExecuteScript("arguments[0].value='" + TestData + "';", wb);

                Assert.IsNotNull(ele);*/
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clearing the Value in Textbox_____________________*/
        public static void Clear_Value(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);
                ele.Click();
                ele.Clear();
                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Entering the Value in Textbox using TagName_____________________*/
        public static void Enter_Value_ByTagName(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElements(By.TagName("input"));

                foreach (IWebElement row in ele)
                {
                    if (row.GetAttribute("type") == xpath)
                    {
                        row.SendKeys(TestData);
                        break;
                    }
                }
                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }

        /* ______________Clicking on the link in the Web Page_____________________*/
        public static void Click_on_link(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string found = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElements(By.TagName("a"));

                foreach (IWebElement row in ele)
                {
                    if (row.GetAttribute("href").Contains(TestData))
                    {
                        row.Click();
                        found = "found";
                        break;
                    }

                    if (found != "found")
                    {
                        if (row.GetAttribute("innerHTML") == TestData)
                        {
                            row.Click();
                            found = "found";
                            break;
                        }
                    }

                }
                Assert.IsNotNull(ele);                
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }

        /* ______________Verifying the Search Link in the Web Page_____________________*/
        public static void Verifying_search_link(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);
                
                Assert.IsNotNull(ele);
                Assert.IsTrue(ele.Text.Contains(TestData));
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }

        /* ______________Verifying Left Navigation in the Browser_____________________*/
        public static void Verify_leftNavigation(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            int i = 0;
            try
            {
                string[] leftnav = TestData.Split(',');
                var ele = driver.FindElement(By.XPath(xpath), 5);
                var elesub = driver.FindElements(By.TagName("li"));

                for (int j = 0; j < elesub.Count; j++)
                {
                    foreach (string word in leftnav)
                    {
                        if (elesub[j].Text != null || elesub[j].Text != "")
                        {
                            if (elesub[j].Text.Contains(word))
                            {
                                i++;
                            }
                        }
                    }
                }
                
                Assert.IsNotNull(ele);
                Assert.IsTrue(leftnav.Count() == i);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Switching to new tab in the Browser_____________________*/
        public static void SwitchToNewTab(string TestStepID, string TestStepDesc, string Keyword, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                driver.SwitchTo().Window(driver.WindowHandles[1]);
                driver.Close();
                System.Threading.Thread.Sleep(2000);
                driver.SwitchTo().Window(driver.WindowHandles[0]);
                System.Threading.Thread.Sleep(5000);
                driver.Manage().Window.Maximize();
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + "" + " - " + "" + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, "", "" + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the Header Tab - Logic is mainly created for IE Browser. In this method, the Tab mentioned will be clicked and then it's repective header section is made visible and then the 'next' link(Ex: General Application) will be clicked in the displayed section._____________________*/
        public static void SortColumnAscending(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;

            try
            {
                var colButton = driver.FindElement(By.XPath(xpath), 5);
                var colSortIcon = driver.FindElement(By.XPath(ColumnSortBtn), 5);

                string sortColumnClass = colSortIcon.GetAttribute("class");

                if (sortColumnClass == "rgIcon rgSortDescIcon")
                {
                    colButton.Click();
                }

            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the Web Element_____________________*/
        public static void Get_Tokens(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);

                text = ele.Text;

                if (text == string.Empty)
                {
                    text = ele.GetAttribute("value");
                }

                string[] li = text.Split('[');

                foreach (string item in li)
                {
                    if (item != string.Empty && item.Contains(']'))
                    {
                        if (tokens[TestData] != null)
                        {
                            tokens[TestData] = tokens[TestData] + "þ" + "[" + item.Substring(0, item.IndexOf(']') + 1);
                        }
                        else
                        {
                            tokens[TestData] = "[" + item.Substring(0, item.IndexOf(']') + 1);
                        }
                    }
                }

                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the Web Element_____________________*/
        public static void Verify_Tokens(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), 5);

                text = ele.Text;

                if (text == string.Empty)
                {
                    text = ele.GetAttribute("value");
                }

                string[] li = tokens[TestData].ToString().Split('þ');
                string tokenName = string.Empty;

                foreach (string item in li)
                {
                    if (text.Contains(item))
                    {
                        FlagTestCase = "Fail";
                        tokenName = item;
                        exMsg = "'" + TestData + "' field still contains the token '" + tokenName + "'";
                        break;
                    }
                }

                Assert.AreEqual("Pass", FlagTestCase);

            }
            catch (Exception ex)
            {
                exMsg = ex.Message;
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Closing the Browser_____________________*/
        public static void CloseBrowser(string TestStepID, string TestStepDesc, string Keyword, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                driver.Quit();

                System.Threading.Thread.Sleep(2000);
                CommonFunctions.KillProcess("chromedriver");
            }
            catch (Exception ex)
            {
               /* exMsg = ex.Message;
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;*/
            }
            finally
            {
                /*Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + string.Empty + " - " + string.Empty + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, string.Empty, string.Empty + "\n" + exMsg, FlagTestCase, RunningTestCase);*/
            }
        }

        /* ______________Highlighting the Web Element using XPath_____________________*/
        public static void highlightUsingXpath(IWebDriver driver, string xpath, string TestStepID, string TestStepDesc, string Keyword, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = string.Empty;
            try
            {
                IWebElement element = driver.FindElement(By.XPath(xpath));
                var jsDriver = (IJavaScriptExecutor)driver;
                string highlightJavascript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color: red"";";
                jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + "" + " - " + "" + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, "", "" + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Alert Handling in Page_____________________*/
        public static void IsAlertPresent(IWebDriver _driver, string Value)
        {
            try
            {
                IAlert alert = _driver.SwitchTo().Alert();
                if (Value == "Accept")
                {
                    alert.Accept();
                    Console.WriteLine("Alert is Accepted");
                }
                else if (Value == "Dismiss")
                {
                    alert.Dismiss();
                    Console.WriteLine("Alert is Dismissed");
                }
                else
                {
                    Console.WriteLine("Alert Action is Indefined");
                }
            }
            catch (NoAlertPresentException NoAlert)
            {
                Console.WriteLine("No Alert is Present");
                Console.WriteLine(NoAlert.StackTrace);
            }
        }
        public static void SetZoom100()
        {
            // Get DPI setting.
            RegistryKey dpiRegistryKey = Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop\\WindowMetrics");
            int dpi = (int)dpiRegistryKey.GetValue("AppliedDPI");
            // 96 DPI / Smaller / 100%
            int zoomFactor100Percent = 100000;
            Console.WriteLine("dpi:" + dpi);
            switch (dpi)
            {
                case 120: // Medium / 125%
                    zoomFactor100Percent = 80000;
                    break;
                case 144: // Larger / 150%
                    zoomFactor100Percent = 66667;
                    break;
            }
            // Get IE zoom.
            RegistryKey zoomRegistryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Internet Explorer\\Zoom", true);
            currentZoomFactor = (int)zoomRegistryKey.GetValue("ZoomFactor");
            Console.WriteLine("Current Zoom" + currentZoomFactor);

            if (currentZoomFactor != zoomFactor100Percent)
            {
                // Set IE zoom and remember the previous value.
                zoomRegistryKey.SetValue("ZoomFactor", zoomFactor100Percent, RegistryValueKind.DWord);
                m_PreviousZoomFactor = currentZoomFactor;
                Console.WriteLine("Updated currentZoomFactor Zoom" + currentZoomFactor);
            }
        }
    }

}
