﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Windows.Forms;


namespace EAppGeneralTestAutomation.Operations
{
    public static class Wait
    {
        /* ______________Extension Method for finding the elements with Explicit wait_____________________*/
        public static IWebElement FindElement(this IWebDriver driver, By by, int timeoutInSeconds)
        {
            try
            {
                if (timeoutInSeconds > 0)
                {
                    var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                    return wait.Until(drv => drv.FindElement(by));
                }
            }
            catch
            {

            }
            return driver.FindElement(by);
        }
    }
}
