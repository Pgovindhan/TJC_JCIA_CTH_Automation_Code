﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EAppGeneralTestAutomation.Utilities;

namespace EAppGeneralTestAutomation.Modules
{
    /// <summary>
    /// Summary description for OMSHome
    /// </summary>
    [TestClass]
    public class EAppGeneral
    {
        public EAppGeneral()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        [TestCategory("PatchTesting"), TestCategory("RegressionTesting")]
        public void EAppGeneral_EApp_TC1()
        {
            TestLogic.TestFail = 0;

            HybridLogic.HybridMethodNew(TestContext.TestName);

            if (HybridLogic.TestCaseFound != "found")
            {
                Assert.Inconclusive();
            }
            else
            {
                string Flag = string.Empty;
                if (TestLogic.TestFail > 0)
                    Flag = "Fail";
                else
                    Flag = "Pass";

                Assert.AreEqual("Pass", Flag);
            }
        }

        [TestMethod]
        [TestCategory("PatchTesting"), TestCategory("RegressionTesting")]
        public void EAppGeneral_EApp_TC2()
        {
            TestLogic.TestFail = 0;

            HybridLogic.HybridMethodNew(TestContext.TestName);

            if (HybridLogic.TestCaseFound != "found")
            {
                Assert.Inconclusive();
            }
            else
            {
                string Flag = string.Empty;
                if (TestLogic.TestFail > 0)
                    Flag = "Fail";
                else
                    Flag = "Pass";

                Assert.AreEqual("Pass", Flag);
            }
        }

        [TestMethod]
        [TestCategory("PatchTesting"), TestCategory("RegressionTesting")]
        public void EAppGeneral_EApp_TC3()
        {
            TestLogic.TestFail = 0;

            HybridLogic.HybridMethodNew(TestContext.TestName);

            if (HybridLogic.TestCaseFound != "found")
            {
                Assert.Inconclusive();
            }
            else
            {
                string Flag = string.Empty;
                if (TestLogic.TestFail > 0)
                    Flag = "Fail";
                else
                    Flag = "Pass";

                Assert.AreEqual("Pass", Flag);
            }
        }

        [TestMethod]
        [TestCategory("PatchTesting"), TestCategory("RegressionTesting")]
        public void EAppGeneral_EApp_TC4()
        {
            TestLogic.TestFail = 0;

            HybridLogic.HybridMethodNew(TestContext.TestName);

            if (HybridLogic.TestCaseFound != "found")
            {
                Assert.Inconclusive();
            }
            else
            {
                string Flag = string.Empty;
                if (TestLogic.TestFail > 0)
                    Flag = "Fail";
                else
                    Flag = "Pass";

                Assert.AreEqual("Pass", Flag);
            }
        }


    }
}
