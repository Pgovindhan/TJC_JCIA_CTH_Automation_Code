-- The purpose of this script is to allow changing the scheduled date for a surveyor
-- on the Mock org used for patch testing.  Currently, the "New Date" would need to
-- be entered here, but updating this script could be unnecessary if a SQL table
-- stored the dates for patch testing.  SRT 1/12/2021

DECLARE @hco_id           int      = 337844,      -- This is fixed.
        @hcop_mevt_id     int      = 43540618,    -- This is fixed.
        @rsc_id           int      = 8000,        -- This is fixed.
        @new_date         datetime = '1/17/2021', -- This should be updated to test date.
        @revt_id          int,
        @revt_svyr_asg_id int,
        @old_date         datetime

-- DATA CHECK -- Make sure mevt_st_typ_id = 4 if it is 6 or 8 or anything else stop.
IF (SELECT mevt_st_typ_id FROM DBSVY01.dbo.t_hcop_mevt WHERE hcop_mevt_id = @hcop_mevt_id) <> 4
   RETURN

-- Get the date from the existing event schedule.
SELECT TOP(1)
       @old_date = scal_dt,
       @revt_id  = revt_id
  FROM DBSVY01.dbo.t_scal
 WHERE hcop_mevt_id    = @hcop_mevt_id
   AND rsc_id          = @rsc_id
   AND scal_rsn_typ_id = 800

-- If script already run or schedule already changed, then get out.
IF @old_date = @new_date
   RETURN

-- Get the revt_svyr_asg_id which is a unique record in t_revt_svyr_asg.  It is also
-- the same value used in t_hcopss (hcop_mevt_svyr_id)
SELECT @revt_svyr_asg_id = revt_svyr_asg_id
  FROM DBSVY01.dbo.t_revt_svyr_asg
 WHERE revt_id = @revt_id
   AND rsc_id  = @rsc_id

-- Make the old date available for the old event and resource.
 UPDATE DBSVY01.dbo.t_scal SET svry_asg_avl_fl = 'Y'
  WHERE scal_rsn_typ_id = 600
    AND rsc_id          = @rsc_id
    AND scal_dt         = @old_date

-- Delete the old surveyor calendar survey event.
DELETE FROM DBSVY01.dbo.t_scal 
 WHERE hcop_mevt_id     = @hcop_mevt_id
   AND rsc_id           = @rsc_id
   AND scal_dt          = @old_date
   AND scal_rsn_typ_id <> 600

-- Insert new calendar records.
-- First check if there are availability records, if not insert them.
IF NOT EXISTS (SELECT TOP(1) 1
                FROM DBSVY01.dbo.t_scal
               WHERE scal_dt         = @new_date
                 AND rsc_id          = @rsc_id
                 AND scal_rsn_typ_id = 600)
BEGIN
   -- AVAILABILITY
   -- Insert day part AM
   INSERT INTO DBSVY01.dbo.t_scal
     (scal_dt, rsc_id, scal_rsn_typ_id, scal_day_typ_id, hcop_mevt_id, revt_id, pfa_rvnu_id, scal_act_scctr_id, scal_act_ecctr_id, scal_trv_mode_cd, svry_asg_avl_fl)
   VALUES
     (@new_date, @rsc_id, 600, 2, 0, 0, 1490, 1490, 1490, 'UNKNOWN', 'Y')

   -- Insert day part PM
   INSERT INTO DBSVY01.dbo.t_scal
     (scal_dt, rsc_id, scal_rsn_typ_id, scal_day_typ_id, hcop_mevt_id, revt_id, pfa_rvnu_id, scal_act_scctr_id, scal_act_ecctr_id, scal_trv_mode_cd, svry_asg_avl_fl)
   VALUES
     (@new_date, @rsc_id, 600, 3, 0, 0, 1490, 1490, 1490, 'UNKNOWN', 'Y')
END

---- Insert day part AM
INSERT INTO DBSVY01.dbo.t_scal
  (scal_dt, rsc_id, scal_rsn_typ_id, scal_day_typ_id, hcop_mevt_id, revt_id, pfa_rvnu_id, scal_act_scctr_id, scal_act_ecctr_id, scal_trv_mode_cd, svry_asg_avl_fl)
VALUES
  (@new_date, @rsc_id, 800, 2, @hcop_mevt_id, @revt_id, 1490, 1490, 1490, 'UNKNOWN', 'N')

---- Insert day part PM
INSERT INTO DBSVY01.dbo.t_scal
  (scal_dt, rsc_id, scal_rsn_typ_id, scal_day_typ_id, hcop_mevt_id, revt_id, pfa_rvnu_id, scal_act_scctr_id, scal_act_ecctr_id, scal_trv_mode_cd, svry_asg_avl_fl)
VALUES
  (@new_date, @rsc_id, 800, 3, @hcop_mevt_id, @revt_id, 1490, 1490, 1490, 'UNKNOWN', 'N')

-- Update the availability flag to N
UPDATE DBSVY01.dbo.t_scal
   SET svry_asg_avl_fl = 'N'
 WHERE scal_dt         = @new_date
   AND scal_rsn_typ_id = 600
   AND rsc_id          = @rsc_id
  
-- Now update the old scheduling record with the new dates.
UPDATE DBSVY01.dbo.t_revt_svyr_asg
   SET revt_svyr_asg_bgn_dt = @new_date,
       revt_svyr_asg_end_dt = @new_date
 WHERE revt_svyr_asg_id = @revt_svyr_asg_id
   AND rsc_id           = @rsc_id  -- This is not necessary but a confirmation

-- Clear the SUBMIT flag
UPDATE DBSVY01.dbo.t_revt_svyr_asg
   SET sbm_fl = 'N'
 WHERE revt_svyr_asg_id = @revt_svyr_asg_id
   AND rsc_id           = @rsc_id  

-- Set the date in t_hcopss 
UPDATE DBSVY02.dbo.t_hcopss
   SET svyr_sch_bgn_dt = @new_date,
       svyr_sch_end_dt = @new_date
 WHERE hcop_mevt_svyr_id = @revt_svyr_asg_id

-- Change the dates in tracking for this event.
UPDATE DBTRK02.dbo.t_tevt_tsk
   SET trk_tsk_dat_dt = @new_date
 WHERE tevt_id = @hcop_mevt_id
   AND trk_dat_typ_id = 1
   AND trk_tsk_dat_typ_id IN (3,4) -- Both Begin/End dates are the same.
