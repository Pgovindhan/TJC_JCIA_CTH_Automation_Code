/* Script 2: After Patch Testing */
/* Set event to Mailed and Lock & Published */
Update DBSVY01.dbo.t_hcop_mevt
SET mevt_st_typ_id = 6                                 /* Mailed */
where hco_mevt_id = 43686774                 /* HCO 337860 LAB Full-U */
 
Update DBSVY01.dbo.t_hco_mevt
SET co_evt_sts_typ_id = 17                          /* LOCKD PUBLSD */
where hco_mevt_id = 43686774                 /* HCO 337860 LAB Full-U */
