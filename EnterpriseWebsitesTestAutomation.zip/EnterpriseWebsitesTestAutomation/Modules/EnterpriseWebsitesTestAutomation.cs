﻿
    using System;
    using EnterpriseWebsitesTestAutomation;
    using EnterpriseWebsitesTestAutomation;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    namespace EnterpriseWebsitesTestAutomation.Modules
    {
        [TestClass]
        public class EnterpriseWebsitesTestAutomation
        {
        const string RegTesting = "RegressionTesting";
        const string PatchTesting = "PatchTesting";
        public EnterpriseWebsitesTestAutomation()
            {
                //
                // TODO: Add constructor logic here
                //
            }

            private TestContext testContextInstance;

            /// <summary>
            ///Gets or sets the test context which provides
            ///information about and functionality for the current test run.
            ///</summary>
            public TestContext TestContext
            {
                get
                {
                    return testContextInstance;
                }
                set
                {
                    testContextInstance = value;
                }
            }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod, TestCategory(PatchTesting), TestCategory(RegTesting)]
        
            public void EnterpriseWebsitesTestAutomation_EnterpriseWebsitesTestAutomation_TC1()
            {
                TestLogic.TestFail = 0;

                string check = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                HybridLogic.HybridMethodNew(TestContext.TestName);

                if (HybridLogic.TestCaseFound != "found")
                {
                    Assert.Inconclusive();
                }
                else
                {
                    string Flag = string.Empty;
                    if (TestLogic.TestFail > 0)
                        Flag = "Fail";
                    else
                        Flag = "Pass";

                    //Assert.AreEqual("Pass", Flag);
                }
            }

            /*[TestMethod]
            [TestCategory("PatchTesting")]
            public void SAM_SAMPCMilerDistance()
            {
                TestLogic.TestFail = 0;

                string check = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                HybridLogic.HybridMethodNew(TestContext.TestName);

                if (HybridLogic.TestCaseFound != "found")
                {
                    Assert.Inconclusive();
                }
                else
                {
                    string Flag = string.Empty;
                    if (TestLogic.TestFail > 0)
                        Flag = "Fail";
                    else
                        Flag = "Pass";

                    //Assert.AreEqual("Pass", Flag);
                }
            }

            [TestMethod]
            [TestCategory("PatchTesting")]
            public void SAM_SAMExpApp()
            {
                TestLogic.TestFail = 0;

                string check = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                HybridLogic.HybridMethodNew(TestContext.TestName);

                if (HybridLogic.TestCaseFound != "found")
                {
                    Assert.Inconclusive();
                }
                else
                {
                    string Flag = string.Empty;
                    if (TestLogic.TestFail > 0)
                        Flag = "Fail";
                    else
                        Flag = "Pass";

                    //Assert.AreEqual("Pass", Flag);
                }
            }


            [TestMethod]
            [TestCategory("PatchTesting")]
            public void SAM_SAMSurveyorCal()
            {
                TestLogic.TestFail = 0;

                string check = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                HybridLogic.HybridMethodNew(TestContext.TestName);

                if (HybridLogic.TestCaseFound != "found")
                {
                    Assert.Inconclusive();
                }
                else
                {
                    string Flag = string.Empty;
                    if (TestLogic.TestFail > 0)
                        Flag = "Fail";
                    else
                        Flag = "Pass";

                    //Assert.AreEqual("Pass", Flag);
                }
            }


            [TestMethod]
            [TestCategory("PatchTesting")]
            public void SAM_SAMTimeCard()
            {
                TestLogic.TestFail = 0;

                string check = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                HybridLogic.HybridMethodNew(TestContext.TestName);

                if (HybridLogic.TestCaseFound != "found")
                {
                    Assert.Inconclusive();
                }
                else
                {
                    string Flag = string.Empty;
                    if (TestLogic.TestFail > 0)
                        Flag = "Fail";
                    else
                        Flag = "Pass";

                    //Assert.AreEqual("Pass", Flag);
                }
            }

            [TestMethod]
            [TestCategory("PatchTesting")]
            public void SAM_SAMReports()
            {
                TestLogic.TestFail = 0;

                string check = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                HybridLogic.HybridMethodNew(TestContext.TestName);

                if (HybridLogic.TestCaseFound != "found")
                {
                    Assert.Inconclusive();
                }
                else
                {
                    string Flag = string.Empty;
                    if (TestLogic.TestFail > 0)
                        Flag = "Fail";
                    else
                        Flag = "Pass";

                    //Assert.AreEqual("Pass", Flag);
                }
            }*/
        }
    }
