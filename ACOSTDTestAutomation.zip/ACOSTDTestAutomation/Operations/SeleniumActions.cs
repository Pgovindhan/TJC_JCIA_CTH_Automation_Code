﻿using System;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ACOSTDTestAutomation.Utilities;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using System.Collections;
using OpenQA.Selenium.Support.Extensions;
using System.Collections.Generic;
using AutoIt;
using CredentialManagement;
using Microsoft.Win32;
using ACOSTDTestAutomation;
using System.Data.SqlClient;
using System.Configuration;
using static System.Net.WebRequestMethods;
using System.Net.Http;
using System.Threading.Tasks;
using OpenQA.Selenium.Remote;

namespace ACOSTDTestAutomation.Operations
{
    public class SeleniumActions
    {
        public static IWebDriver driver = null;

        public static string ClickTab_NextLink;
        public static string ClickTab_TabToDisplay;

        public static string ColumnSortBtn;

        public static string HCO_ID;
        public static Hashtable tokens = new Hashtable();
        public static Hashtable StoredDetails = new Hashtable();

        static string GlobalWaitTime = "10";
        static int GlobalWaitTime_int = int.Parse(GlobalWaitTime);
        public static string window = "";
        //Selenium Actions Decleration part

        private const string PasswordName = "SAM";
        private static int m_PreviousZoomFactor = 0;
        private static int currentZoomFactor;


        // Save Password to window Credential manager
        public static void SavePassword(string password)
        {
            using (var cred = new Credential())
            {
                cred.Password = password;
                cred.Target = PasswordName;
                cred.Type = CredentialType.Generic;
                cred.PersistanceType = PersistanceType.LocalComputer;
                cred.Save();
            }
        }

        // Get password from Windows credential manager
        private static string GetPassword(string Target)
        {
            using (var cred = new Credential())
            {
                cred.Target = Target;
                cred.Load();
                return base64Encode(cred.Password);
            }
        }

        //Encode the password
        public static string base64Encode(string data)
        {
            try
            {
                byte[] enData_byte = new byte[data.Length];
                enData_byte = System.Text.Encoding.UTF8.GetBytes(data);
                string encodedData = Convert.ToBase64String(enData_byte);
                return encodedData;
            }
            catch (Exception e)
            {
                throw new Exception("Error in base4encode" + e.Message);
            }
        }

        // Decode the password
        public static string base64Decode(string sdata)
        {
            try
            {
                System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
                System.Text.Decoder utf8Decoder = encoder.GetDecoder();
                byte[] todecode_byte = Convert.FromBase64String(sdata);
                int charCount = utf8Decoder.GetCharCount(todecode_byte, 0, todecode_byte.Length);
                char[] decoder_char = new char[charCount];
                utf8Decoder.GetChars(todecode_byte, 0, todecode_byte.Length, decoder_char, 0);
                string result = new string(decoder_char);
                return result;
            }
            catch (Exception e)
            {
                throw new Exception("Error in base4encode" + e.Message);
            }
        }

        //get the current username
        public static string GetCurrentLoggedInUserName()
        {
            return Environment.UserName;
        }

        /* ______________Invoking the web drivers_____________________
        /**********************************************
               Function : InvokeBrowser
               Function Desc: Opens desire browser
               I/P args: Null 
               Return Value: void
               Precondition: All browers should be closed for better automation
               Author: Vincent 
        ************************************************ */
        public static IWebDriver InvokeBrowser(string testMethodName, string module, string browser, string url)
        {
            string BrowserFlag = "WindowsAuth";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                switch (browser.ToUpper().Trim())
                {
                    case "IE":
                    case "INTERNET EXPLORER":
                    case "IEXPLORER":
                        System.Threading.Thread.Sleep(2000);

                        if (BrowserFlag == "MSAuth_TJC")
                        {
                            if (driver == null)
                            {
                                var options = new InternetExplorerOptions();
                                options.EnsureCleanSession = true;
                                options.BrowserCommandLineArguments = "-private";
                                driver = new InternetExplorerDriver(options);
                                driver.Manage().Window.Maximize();
                                driver.Navigate().GoToUrl(url);
                                Assert.IsNotNull(driver);
                            }
                            else
                            {
                                driver.Manage().Window.Maximize();
                                driver.Navigate().GoToUrl(url);
                            }
                        }

                        if (BrowserFlag == "WindowsAuth")
                        {
                            var options = new InternetExplorerOptions();
                            options.EnsureCleanSession = true;
                            options.BrowserCommandLineArguments = "-private";
                            driver = new InternetExplorerDriver(options);
                            driver.Manage().Window.Maximize();
                            driver.Navigate().GoToUrl(url);
                            Assert.IsNotNull(driver);
                        }

                        break;

                    case "CHROME":
                    case "Chrome":
                    case "chrome":


                        ChromeOptions GCoptions = new ChromeOptions();
                        GCoptions.AddArgument("incognito");
                        GCoptions.AddArgument("test-type");
                        GCoptions.AddArgument("--start-maximized");
                        // Initialize the Chrome Driver
                        driver = new ChromeDriver(GCoptions);
                        driver.Navigate().GoToUrl(url);
                        driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

                        break;

                    case "MOZILLA":
                    case "FIREFOX":
                        Console.WriteLine(Directory.GetCurrentDirectory());// + "\\Debug");
                        FirefoxDriverService service = FirefoxDriverService.CreateDefaultService(Directory.GetCurrentDirectory());// + "\\Debug");
                        service.FirefoxBinaryPath = @"C:\Program Files (x86)\Mozilla Firefox\firefox.exe";
                        driver = new FirefoxDriver(service);
                        driver.Navigate().GoToUrl(url);
                        break;

                    default:
                        {
                            var options1 = new InternetExplorerOptions();
                            options1.EnsureCleanSession = true;
                            driver = new InternetExplorerDriver(options1);
                            driver.Manage().Window.Maximize();
                            driver.Navigate().GoToUrl(url);
                            Assert.IsNotNull(driver);
                        }
                        break;
                }

            }
            catch (Exception ex)
            {
                FlagTestCase = "Fail";
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
                TestLogic.Flag++;
            }
            return driver;
        }

        /* ______________Launching the desire browser_____________________*/
        public static void InvokeBrowser(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            var downloadDirectory = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName + "\\TestDownloads";
            if (!(Directory.Exists(downloadDirectory)))
            {
                Directory.CreateDirectory(downloadDirectory);
            }

            try
            {
                switch (browser.ToUpper())
                {
                    case "IE":
                    case "INTERNET EXPLORER":
                    case "IEXPLORER":

                        var options = new InternetExplorerOptions();
                        options.EnsureCleanSession = true;
                        options.BrowserCommandLineArguments = "-private";
                        options.EnsureCleanSession = true;
                        options.IgnoreZoomLevel = true;
                        
                        //driver.Manage().Cookies.DeleteAllCookies();
                        driver = new InternetExplorerDriver(options);                        
                        driver.Manage().Window.Maximize();
                        driver.Navigate().GoToUrl(TestData);
                        SetZoom100();
                        Console.WriteLine("Zoom "+ currentZoomFactor);
                        /*if(currentZoomFactor!=66667)
                        {
                            driver.Quit();
                            driver.Navigate().GoToUrl(TestData);

                        }
                        ((IJavaScriptExecutor)driver).ExecuteScript("document.body.style.zoom = '100%';");*/
                        

                        //IWebDriver driver = new RemoteWebDriver(DesiredCapabilities.HtmlUnitWithJavaScript())

                        break;

                    case "CHROME":
                    case "GOOGLE CHROME":
                    case "GOOGLECHROME":

                        ChromeOptions GCoptions = new ChromeOptions();

                        GCoptions.AddUserProfilePreference("download.default_directory", downloadDirectory);
                        GCoptions.AddUserProfilePreference("download.prompt_for_download", false);
                        GCoptions.AddUserProfilePreference("disable-popup-blocking", "true");

                        GCoptions.AddArgument("test-type");
                        GCoptions.AddArgument("--start-maximized");
                        GCoptions.AddArgument("--no-sandbox");
                        //Testconnection_update();
                        // Initialize the Chrome Driver
                        driver = new ChromeDriver(GCoptions);
                        driver.Navigate().GoToUrl(TestData);
                        break;
                        /*var options1 = new InternetExplorerOptions();
                        options1.EnsureCleanSession = true;
                        options1.BrowserCommandLineArguments = "-private";
                        options1.EnsureCleanSession = true;
                        options1.IgnoreZoomLevel = true;

                        //driver.Manage().Cookies.DeleteAllCookies();
                        driver = new InternetExplorerDriver(options1);
                        driver.Manage().Window.Maximize();
                        driver.Navigate().GoToUrl(TestData);
                        SetZoom100();
                        Console.WriteLine("Zoom " + currentZoomFactor);
                        break;*/

                    case "MOZILLA":
                    case "MOZILLAFIREFOX":
                    case "FIREFOX":
                        Console.WriteLine(Directory.GetCurrentDirectory());// + "\\Debug");
                        FirefoxDriverService service = FirefoxDriverService.CreateDefaultService(Directory.GetCurrentDirectory());// + "\\Debug");
                        service.FirefoxBinaryPath = @"C:\Program Files (x86)\Mozilla Firefox\firefox.exe";

                        FirefoxProfile profile = new FirefoxProfile();
                        profile.AcceptUntrustedCertificates = true;
                        profile.AssumeUntrustedCertificateIssuer = false;

                        FirefoxOptions opt = new FirefoxOptions();
                        opt.AcceptInsecureCertificates = true;
                        opt.Profile = profile;

                        opt.SetPreference("download.default_directory", downloadDirectory);
                        opt.SetPreference("download.prompt_for_download", false);
                        opt.SetPreference("disable-popup-blocking", "true");

                        driver = new FirefoxDriver(service, opt, TimeSpan.FromMinutes(1));
                        driver.Navigate().GoToUrl(TestData);
                        Thread.Sleep(5000);

                        try
                        {
                            //int i = 0;
                            //while (i < 2)
                            //{
                            IAlert alert = driver.SwitchTo().Alert();
                            SendKeys.SendWait("kumaran@jcaho.net");
                            Thread.Sleep(2000);
                            SendKeys.SendWait("{TAB}");
                            Thread.Sleep(2000);
                            //............................Used SendKeys of System.Windows.Forms.........................//
                            SendKeys.SendWait("Winwire@123");

                            Thread.Sleep(2000);
                            SendKeys.SendWait("{TAB}");
                            Thread.Sleep(2000);
                            alert.Accept();
                            Thread.Sleep(12000);
                            //i++;
                            //}
                        }
                        catch
                        {

                        }
                        break;

                    default:
                        Reports.Report_TestDataStep(driver, TestStepID, "'" + browser + "' does not exist in the list, please provide valid browser name", Keyword, ObjectName, TestData, "Fail", RunningTestCase);
                        break;
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }

        public static void Login_Popup(string browser, string TestData, string sTestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                switch (browser.ToUpper())
                {
                    case "IE":
                    case "INTERNET EXPLORER":
                    case "IEXPLORER":

                        break;

                    case "CHROME":
                    case "GOOGLE CHROME":
                    case "GOOGLECHROME":

                        //get user name
                        string userName = GetCurrentLoggedInUserName();

                        //save password
                        //SavePassword("");

                        //get the encoded password
                        string encodedPassword = GetPassword("SAM");
                        Console.WriteLine(encodedPassword);
                        //decoded password and save it 
                        string decodedPassword = base64Decode(encodedPassword);
                        Console.WriteLine(decodedPassword);

                        AutoItX.Send(userName);
                        AutoItX.Send("{Tab}");
                        //Thread.Sleep(5000);
                        AutoItX.Send(decodedPassword);
                        //Thread.Sleep(5000);
                        AutoItX.Send("{Enter}");
                        break;

                    case "MOZILLA":
                    case "MOZILLAFIREFOX":
                    case "FIREFOX":

                        break;

                    default:
                        Reports.Report_TestDataStep(driver, sTestStepID, "'" + browser + "' does not exist in the list, please provide valid browser name", Keyword, ObjectName, TestData, "Fail", RunningTestCase);
                        break;
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(sTestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, sTestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }


        /* ______________Navigate Browser To Specific URL_____________________*/
        public static void NavigateTo(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                driver.Navigate().GoToUrl(TestData);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the Browser for complete loading of the URL_____________________*/
        public static void Browser_Verification(string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var brow = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);

            if (brow.Text == xpath_verification)
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData, "Pass", RunningTestCase);

            else
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData, "Fail", RunningTestCase);

        }

        /* ______________Taking Screenshots in case of error_____________________*/
        public Screenshot CaptureImages()
        {
            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            return ss;
        }

        /* ______________Clicking on the Web Element_____________________*/
        public static void Click_on(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                //System.Threading.Thread.Sleep(1000);
                //String window = driver.CurrentWindowHandle;
                //Console.WriteLine(window);
                //IWebElement ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                //((IJavaScriptExecutor)driver).ExecuteScript("arguments[0];", ele);
                //////Thread.Sleep(5000);
                //if (ele.Enabled)
                //{
                //    ele.Click();
                //    flag = "found";
                //}
                IWebElement ele = driver.FindElement(By.XPath(xpath));
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;

                js.ExecuteScript("arguments[0].click();", ele);
                flag = "found";
                Assert.IsNotNull(ele);

                if (flag == "")
                {
                    if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                    {
                        HybridLogic.bProceedOnFail = false;
                    }
                    FlagTestCase = "Fail";
                    TestLogic.TestFail++;
                    exMsg = "Element is not enabled";
                }

               Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        public static void Print_Window(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                System.Threading.Thread.Sleep(1000);
                IReadOnlyCollection<string> windows = driver.WindowHandles;
                window = driver.CurrentWindowHandle;
                foreach (var win in windows)
                {
                    Console.WriteLine(win);
                    if (win != window)
                    {
                        driver.SwitchTo().Window(win);
                        driver.Close();
                    }
                }
                driver.SwitchTo().Window(window);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the HCO Tab - Created for IE Browser_____________________*/
        public static void Click_HCO(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                CommonFunctions.highlight(driver, ele);
                text = ele.Text;

                if (browser.Trim().ToUpper() == "IE" || browser.Trim().ToUpper() == "INTERNET EXPLORER" || browser.Trim().ToUpper() == "IEXPLORER")
                {
                    bool clicked = false;
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();
                    while (!clicked && stopwatch.Elapsed < TimeSpan.FromSeconds(100))
                    {
                        Actions act = new Actions(driver);
                        act.MoveToElement(ele).Perform();
                        System.Threading.Thread.Sleep(2000);
                        act.Click(ele).Perform();
                        try
                        {
                            string check = driver.FindElement(By.XPath(".//span[contains(text(),'" + HCO_ID + "')]/.."), GlobalWaitTime_int).Text;
                            clicked = true;
                        }
                        catch
                        {

                        }
                    }
                }
                else
                {
                    ele.Click();
                }

                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the Header Tab - Logic is mainly created for IE Browser. In this method, the Tab mentioned will be clicked and then it's repective header section is made visible and then the 'next' link(Ex: General Application) will be clicked in the displayed section._____________________*/
        public static void Click_Tab(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                CommonFunctions.highlight(driver, ele);
                text = ele.Text;

                if (browser.Trim().ToUpper() == "CHROME" || browser.Trim().ToUpper() == "GOOGLE CHROME" || browser.Trim().ToUpper() == "GOOGLECHROME")
                {
                    ele.Click();
                    System.Threading.Thread.Sleep(3000);
                    driver.FindElement(By.XPath(ClickTab_NextLink), GlobalWaitTime_int).Click();
                }
                else
                {
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();
                    int windowsCount = driver.WindowHandles.Count;

                    Actions act = new Actions(driver);

                    var jsDriver = (IJavaScriptExecutor)driver;
                    string highlightJavascript = "document.getElementById('" + ClickTab_TabToDisplay + "').style.display = 'block';";

                    try
                    {
                        var ele2 = driver.FindElement(By.XPath(ClickTab_NextLink), GlobalWaitTime_int);

                        act.MoveToElement(ele2).Perform();
                        System.Threading.Thread.Sleep(3000);
                        jsDriver.ExecuteScript(highlightJavascript);

                        ele2.Click();

                        System.Threading.Thread.Sleep(3000);
                        if (browser.Trim().ToUpper() == "IE" || browser.Trim().ToUpper() == "INTERNET EXPLORER" || browser.Trim().ToUpper() == "IEXPLORER")
                        {
                            jsDriver.ExecuteScript(highlightJavascript);
                            ele2.Click();

                            System.Threading.Thread.Sleep(3000);
                            driver.Close();
                            System.Threading.Thread.Sleep(3000);
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Mouse Over the Header Tab - Logic is mainly created for IE Browser. In this method, the Mouse Hover the Tab mentioned  then it's repective header section is made visible and then the 'next' link(Ex: General Application) will be clicked in the displayed section._____________________*/
        public static void Click_Tab2(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                CommonFunctions.highlight(driver, ele);
                text = ele.Text;

                if (browser.Trim().ToUpper() == "CHROME" || browser.Trim().ToUpper() == "GOOGLE CHROME" || browser.Trim().ToUpper() == "GOOGLECHROME")
                {
                    //ele.Click();
                    //System.Threading.Thread.Sleep(3000);
                    Actions action = new Actions(driver);

                    action.MoveToElement(ele).Perform();
                    System.Threading.Thread.Sleep(3000);
                    driver.FindElement(By.XPath(ClickTab_NextLink), GlobalWaitTime_int).Click();
                }
                else
                {
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();
                    int windowsCount = driver.WindowHandles.Count;

                    Actions act = new Actions(driver);

                    var jsDriver = (IJavaScriptExecutor)driver;
                    string highlightJavascript = "document.getElementById('" + ClickTab_TabToDisplay + "').style.display = 'block';";

                    try
                    {
                        //String currentURL = driver.Url;
                        act.MoveToElement(ele).Perform();
                        Thread.Sleep(3000);
                        jsDriver.ExecuteScript(highlightJavascript);
                        Thread.Sleep(2000);
                        var ele2 = driver.FindElement(By.XPath(ClickTab_NextLink), GlobalWaitTime_int);
                        ele2.Click();


                        Thread.Sleep(3000);
                        if (browser.Trim().ToUpper() == "IE" || browser.Trim().ToUpper() == "INTERNET EXPLORER" || browser.Trim().ToUpper() == "IEXPLORER")
                        {
                            jsDriver.ExecuteScript(highlightJavascript);
                            ele2.Click();

                            System.Threading.Thread.Sleep(3000);
                            jsDriver.ExecuteScript(highlightJavascript);
                            ele2.Click();

                            System.Threading.Thread.Sleep(3000);
                            driver.Close();
                            System.Threading.Thread.Sleep(3000);
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Getting the Text from a Web Element_____________________*/
        public static void Get_Text(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string gettext_text = "";
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var gettext = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                gettext_text = gettext.Text;
                Assert.IsNotNull(gettext);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }


        }

        /* ______________Hovering the Cursor on the Web Element_____________________*/
        public static void Mouse_Hover(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var element = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                Actions action = new Actions(driver);
                action.MoveToElement(element).Perform();

                Assert.IsNotNull(element);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Waiting the browser for specific time_____________________*/
        public static void Wait_For(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                int waitFor = Convert.ToInt32(TestData);
                if (browser.Trim().ToUpper() == "CHROME" || browser.Trim().ToUpper() == "GOOGLE CHROME" || browser.Trim().ToUpper() == "GOOGLECHROME")
                {
                    waitFor = (waitFor * Int32.Parse(Reports.ChromeWaitPercentage)) / 100;
                    TestData = waitFor.ToString();
                }
                else if (browser.Trim().ToUpper() == "MOZILLA" || browser.Trim().ToUpper() == "MOZILLAFIREFOX" || browser.Trim().ToUpper() == "FIREFOX")
                {
                    waitFor = (waitFor * Int32.Parse(Reports.FirefoxWaitPercentage)) / 100;
                    TestData = waitFor.ToString();
                }
                System.Threading.Thread.Sleep(waitFor);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Waiting the browser for specific time - Equally for all the Browsers_____________________*/
        public static void Wait_ForEqually(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                int waitFor = Convert.ToInt32(TestData);
                System.Threading.Thread.Sleep(waitFor);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Selecting the option in the List by Text_____________________*/
        public static void SelectByText(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                var selectElement = new SelectElement(ele);

                // select by text in a dropdownlist
                selectElement.SelectByText(TestData);
                Assert.IsNotNull(selectElement);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Selecting the option in the List by Value_____________________*/
        public static void SelectByValue(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                var selectElement = new SelectElement(ele);

                // select by value in a dropdownlist
                selectElement.SelectByValue(TestData);
                Assert.IsNotNull(selectElement);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Selecting the option in the List by Index_____________________*/
        public static void SelectByIndex(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                var selectElement = new SelectElement(ele);

                // select by text in a dropdownlist
                selectElement.SelectByIndex(Convert.ToInt32(TestData));
                Assert.IsNotNull(selectElement);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the Value of Web Element_____________________*/
        public static void verification_value(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var tr_collection1 = driver.FindElements(By.XPath(xpath));

                foreach (IWebElement row in tr_collection1)
                {
                    if (row.Text.Contains(TestData))
                    {
                        flag = "pass";
                        break;
                    }
                }

                Assert.AreSame("pass", flag, TestData + " - Text is not found in the " + ObjectName + " object");
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying Web Element is present in the page or not_____________________*/
        public static void Verify_Element(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                IWebElement element = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);

                Assert.IsNotNull(element);
                exMsg = ObjectName + " is displayed";
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying downloaded file present or not_____________________*/
        public static void Download_Verification(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            //{
            //    var downloadDirectory = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName + "\\TestDownloads";
            //    int filesCountBefore = Directory.GetFiles(downloadDirectory).Count();

            //    IWebElement element = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
            //    element.Click();

            //    Thread.Sleep(10000);
            //    exMsg = "File has been dowloaded successfully";
            //    if (browser.Trim().ToUpper() == "CHROME" || browser.Trim().ToUpper() == "GOOGLE CHROME" || browser.Trim().ToUpper() == "GOOGLECHROME")
            //    {
            //        int filesCountAfter = Directory.GetFiles(downloadDirectory).Count();
            //        if (!(filesCountAfter > filesCountBefore))
            //        {
            //            FlagTestCase = "Fail";
            //            TestLogic.TestFail++;
            //            exMsg = "File has not been dowloaded successfully";
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
            //    {
            //        HybridLogic.bProceedOnFail = false;
            //    }
            //    FlagTestCase = "Fail";
            //    TestLogic.TestFail++;
            //    exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            //}
            //finally
            //{
            //    Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
            //    Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            //}

            {
                if (browser.Trim().ToUpper() == "CHROME" || browser.Trim().ToUpper() == "GOOGLE CHROME" || browser.Trim().ToUpper() == "GOOGLECHROME")
                {
                    var downloadDirectory = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName + "\\TestDownloads";
                    int filesCountBefore = Directory.GetFiles(downloadDirectory).Count();

                    IWebElement element = driver.FindElement(By.XPath(xpath), 60);
                    element.Click();

                    Thread.Sleep(10000);
                    exMsg = "File has been dowloaded successfully";
                    int filesCountAfter = Directory.GetFiles(downloadDirectory).Count();
                    if (!(filesCountAfter > filesCountBefore))
                    {
                        FlagTestCase = "Fail";
                        TestLogic.TestFail++;
                        exMsg = "File has not been dowloaded successfully";
                    }
                    CommonFunctions.DeleteAllFilesInFolder(downloadDirectory);
                }
                else if (browser.Trim().ToUpper() == "MOZILLA" || browser.Trim().ToUpper() == "MOZILLAFIREFOX" || browser.Trim().ToUpper() == "FIREFOX")
                {
                    var downloadDirectory = "";//KnownFolders.Downloads.Path;
                    int filesCountBefore = Directory.GetFiles(downloadDirectory).Count();

                    IWebElement element = driver.FindElement(By.XPath(xpath), 60);
                    element.Click();

                    Thread.Sleep(5000);
                    SendKeys.SendWait("{DOWN}");
                    Thread.Sleep(3000);
                    SendKeys.SendWait(@"{Enter}");
                    Thread.Sleep(10000);

                    exMsg = "File has been dowloaded successfully";
                    int filesCountAfter = Directory.GetFiles(downloadDirectory).Count();
                    if (!(filesCountAfter > filesCountBefore))
                    {
                        FlagTestCase = "Fail";
                        TestLogic.TestFail++;
                        exMsg = "File has not been dowloaded successfully";
                    }
                }
                else if (browser.Trim().ToUpper() == "IE" || browser.Trim().ToUpper() == "INTERNET EXPLORER" || browser.Trim().ToUpper() == "IEXPLORER")
                {
                    var downloadDirectory = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName + "\\TestDownloads";
                    int filesCountBefore = Directory.GetFiles(downloadDirectory).Count();

                    IWebElement element = driver.FindElement(By.XPath(xpath), 60);
                    string fileName = element.Text;

                    Actions actions = new Actions(driver);
                    actions.ContextClick(element).Perform();
                    Thread.Sleep(2000);
                    SendKeys.SendWait("{DOWN}");
                    Thread.Sleep(1000);
                    SendKeys.SendWait("{DOWN}");
                    Thread.Sleep(1000);
                    SendKeys.SendWait("{DOWN}");
                    Thread.Sleep(1000);
                    SendKeys.SendWait("{DOWN}");
                    Thread.Sleep(1000);
                    SendKeys.SendWait("{ENTER}");
                    Thread.Sleep(7000);
                    SendKeys.SendWait(downloadDirectory + @"\" + fileName);
                    Thread.Sleep(3000);
                    SendKeys.SendWait(@"{Enter}");

                    Thread.Sleep(4000);
                    exMsg = "File has been dowloaded successfully";
                    int filesCountAfter = Directory.GetFiles(downloadDirectory).Count();
                    if (!(filesCountAfter > filesCountBefore))
                    {
                        FlagTestCase = "Fail";
                        TestLogic.TestFail++;
                        exMsg = "File has not been dowloaded successfully";
                    }

                    CommonFunctions.DeleteAllFilesInFolder(downloadDirectory);
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }

        /* ______________Verifying Documents Links_____________________*/
        public static void Verify_DocumentsLinks(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var tr_collection1 = driver.FindElements(By.XPath(xpath));
                int i = 0;
                foreach (IWebElement row in tr_collection1)
                {
                    row.Click();
                    Thread.Sleep(3000);
                    flag = "clicked";
                    i++;
                }

                if (flag == "clicked")
                {
                    exMsg = i + " document links has been clicked";
                }
                else
                {
                    exMsg = "There are no document links available";
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the Value of Web Element is not equal to Empty_____________________*/
        public static void Verification_NotEmpty(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var tr_collection1 = driver.FindElements(By.XPath(xpath));

                foreach (IWebElement row in tr_collection1)
                {
                    if (row.Text.Trim() != string.Empty)
                    {
                        flag = "pass";
                        break;
                    }
                }

                Assert.AreSame("pass", flag, ObjectName + " - Object doesn't contain any text");
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the list of Web Elements_____________________*/
        public static void verification_list(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var tr_collection1 = driver.FindElements(By.XPath(xpath));

                foreach (IWebElement row in tr_collection1)
                {
                    if (row.Text.Contains(TestData))
                    {
                        flag = "pass";
                    }
                    else
                    {
                        flag = "fail";
                        break;
                    }
                }

                Assert.AreSame("pass", flag, TestData + " - Text is not found in the " + ObjectName + " object");
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the validation in the page. If validation is present, Test will fail_____________________*/
        public static void verification_NoValidation(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                IWebElement ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                //if element is present, then test is failed else passed
                FlagTestCase = "Fail";

                TestLogic.TestFail++;

                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }

                exMsg = "The validation is found in the page, thus Test Step " + TestStepID + " has failed";
            }
            catch
            {
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        ///* ______________Verifying the Value of PDF_____________________*/
        //public static void verification_PDF(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        //{
        //    string FlagTestCase = "Pass";
        //    string exMsg = "";

        //    try
        //    {
        //        string pdfContent, saveFile = string.Empty;

        //        if (browser.Trim().ToUpper() == "IE" || browser.Trim().ToUpper() == "INTERNET EXPLORER" || browser.Trim().ToUpper() == "IEXPLORER")
        //        {
        //            saveFile = CommonFunctions.SaveAction_IE("PDFVerify");
        //            Thread.Sleep(3000);
        //        }
        //        else
        //        {
        //            saveFile = CommonFunctions.SaveAction("PDFVerify");
        //            Thread.Sleep(1000);
        //        }

        //        TextExtractor textExtractor = new TextExtractor();
        //        pdfContent = textExtractor.Extract(saveFile).Text;

        //        if (!pdfContent.Contains(TestData))
        //        {
        //            FlagTestCase = "Fail";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
        //        {
        //            HybridLogic.bProceedOnFail = false;
        //        }
        //        FlagTestCase = "Fail";
        //        TestLogic.TestFail++;
        //        exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
        //    }
        //    finally
        //    {
        //        Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
        //        Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
        //    }
        //}

        /* ______________Storing the Value of Web Element_____________________*/
        public static void Store_Details(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string text = "";
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);

                text = ele.Text;

                if (text == string.Empty)
                {
                    text = ele.GetAttribute("value");
                }

                StoredDetails[TestData] = text;
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, text + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying the Stored Value_____________________*/
        public static void VerifyStored_Details(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string text = "";
            string chkText = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);

                text = ele.Text;

                if (text == string.Empty)
                {
                    text = ele.GetAttribute("value");
                }

                chkText = StoredDetails[TestData].ToString().Trim();

                if (text.Contains(" January ") || text.Contains(" February ") || text.Contains(" March ") || text.Contains(" April ")
                 || text.Contains(" June ") || text.Contains(" July ") || text.Contains(" August ") || text.Contains(" September ")
                 || text.Contains(" October ") || text.Contains(" November ") || text.Contains(" December "))
                {
                    chkText = StoredDetails[TestData].ToString().Trim()
                            .Replace(" Jan ", " January ")
                            .Replace(" Feb ", " February ")
                            .Replace(" Mar ", " March ")
                            .Replace(" Apr ", " April ")
                            .Replace(" Jun ", " June ")
                            .Replace(" Jul ", " July ")
                            .Replace(" Aug ", " August ")
                            .Replace(" Sep ", " September ")
                            .Replace(" Oct ", " October ")
                            .Replace(" Nov ", " November ")
                            .Replace(" Dec ", " December ");
                }

                if (!(text.Contains(chkText)))
                {
                    FlagTestCase = "Fail";
                }

                Assert.AreEqual("Pass", FlagTestCase, ObjectName + " - object does not contain the text '" + chkText + "' instead it is having '" + text + "'");
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "").Replace("Assert.AreEqual failed. Expected:. Actual:. ", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, chkText + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Entering the Value in Textbox_____________________*/
        public static void Enter_Value(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                ele.Click();
                ele.Clear();
                ele.SendKeys(TestData);
                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clearing the Value in Textbox_____________________*/
        public static void Clear_Value(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                ele.Click();
                ele.Clear();
                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Entering the Value in Textbox using TagName_____________________*/
        public static void Enter_Value_ByTagName(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElements(By.TagName("input"));

                foreach (IWebElement row in ele)
                {
                    if (row.GetAttribute("type") == xpath)
                    {
                        row.SendKeys(TestData);
                        break;
                    }
                }
                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }

        /* ______________Clicking on the link in the Web Page_____________________*/
        public static void Click_on_link(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string found = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElements(By.TagName("a"));

                foreach (IWebElement row in ele)
                {
                    if (row.GetAttribute("href").Contains(TestData))
                    {
                        row.Click();
                        found = "found";
                        break;
                    }

                    if (found != "found")
                    {
                        if (row.GetAttribute("innerHTML") == TestData)
                        {
                            row.Click();
                            found = "found";
                            break;
                        }
                    }

                }
                Assert.IsNotNull(ele);

                if (found == "")
                {
                    flag = "fail";
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }

        /* ______________Verifying the Search Link in the Web Page_____________________*/
        public static void Verifying_search_link(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);

                if (ele.Text.Contains(TestData))
                {
                    flag = "pass";
                }

                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }

        }

        /* ______________Verifying Left Navigation in the Browser_____________________*/
        public static void Verify_leftNavigation(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            int i = 0;
            try
            {
                string[] leftnav = TestData.Split(',');
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                var elesub = driver.FindElements(By.TagName("li"));

                for (int j = 0; j < elesub.Count; j++)
                {
                    foreach (string word in leftnav)
                    {
                        if (elesub[j].Text != null || elesub[j].Text != "")
                        {
                            if (elesub[j].Text.Contains(word))
                            {
                                i++;
                            }
                        }
                    }
                }

                if (leftnav.Count() == i)
                {
                    flag = "pass";
                }
                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Switching to new tab in the Browser_____________________*/
        public static void SwitchToNewTab(string TestStepID, string TestStepDesc, string Keyword, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                string windowName = driver.WindowHandles.Last();
                Thread.Sleep(5000);
                driver.SwitchTo().Window(windowName);
                Thread.Sleep(5000);
                driver.Manage().Window.Maximize();
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + "" + " - " + "" + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, "", "" + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Verifying and Closing Dialog_____________________*/
        public static void Verify_CloseDialog(string TestStepID, string TestStepDesc, string Keyword, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                SendKeys.SendWait("5000");
                Thread.Sleep(3000);
                SendKeys.SendWait("(%{F4})");
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + "" + " - " + "" + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, "", "" + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the Header Tab - Logic is mainly created for IE Browser. In this method, the Tab mentioned will be clicked and then it's repective header section is made visible and then the 'next' link(Ex: General Application) will be clicked in the displayed section._____________________*/
        public static void SortColumnAscending(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {
                var colButton = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                var colSortIcon = driver.FindElement(By.XPath(ColumnSortBtn), GlobalWaitTime_int);

                string sortColumnClass = colSortIcon.GetAttribute("class");

                if (sortColumnClass == "rgIcon rgSortDescIcon")
                {
                    colButton.Click();
                }

            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the Web Element_____________________*/
        public static void Get_Tokens(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);

                text = ele.Text;

                if (text == string.Empty)
                {
                    text = ele.GetAttribute("value");
                }

                string[] li = text.Split('[');

                foreach (string item in li)
                {
                    if (item != string.Empty && item.Contains(']'))
                    {
                        if (tokens[TestData] != null)
                        {
                            tokens[TestData] = tokens[TestData] + "þ" + "[" + item.Substring(0, item.IndexOf(']') + 1);
                        }
                        else
                        {
                            tokens[TestData] = "[" + item.Substring(0, item.IndexOf(']') + 1);
                        }
                    }
                }

                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Clicking on the Web Element_____________________*/
        public static void Verify_Tokens(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            var text = "";
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);

                text = ele.Text;

                if (text == string.Empty)
                {
                    text = ele.GetAttribute("value");
                }

                string[] li = tokens[TestData].ToString().Split('þ');
                string tokenName = string.Empty;

                foreach (string item in li)
                {
                    if (text.Contains(item))
                    {
                        FlagTestCase = "Fail";
                        tokenName = item;
                        exMsg = "'" + TestData + "' field still contains the token '" + tokenName + "'";
                        break;
                    }
                }

                Assert.AreEqual("Pass", FlagTestCase);

            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Closing the Browser_____________________*/
        public static void CloseBrowser(string TestStepID, string TestStepDesc, string Keyword, string RunningTestCase)
        {
            try
            {
                driver.Quit();
            }
            catch { }
        }

        /* ______________Closing the Browser_____________________*/
        public static void CloseTab(string TestStepID, string TestStepDesc, string Keyword, string RunningTestCase)
        {
            try
            {
                driver.Close();
                Thread.Sleep(5000);
                string windowName = driver.WindowHandles.Last();
                Thread.Sleep(5000);
                driver.SwitchTo().Window(windowName);
                Thread.Sleep(5000);
                driver.Manage().Window.Maximize();
            }
            catch { }
        }


        /* ______________Highlighting the Web Element using XPath_____________________*/
        public static void highlightUsingXpath(IWebDriver driver, string xpath, string TestStepID, string TestStepDesc, string Keyword, string RunningTestCase)
        {
            string FlagTestCase = "Pass";
            string exMsg = "";
            try
            {
                IWebElement element = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                var jsDriver = (IJavaScriptExecutor)driver;
                string highlightJavascript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color: red"";";
                jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + "" + " - " + "" + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, "", "" + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        /* ______________Alert Handling in Page_____________________*/
        public static void IsAlertPresent(IWebDriver _driver, string Value)
        {
            try
            {
                IAlert alert = _driver.SwitchTo().Alert();
                if (Value == "Accept")
                {
                    alert.Accept();
                    Console.WriteLine("Alert is Accepted");
                }
                else if (Value == "Dismiss")
                {
                    alert.Dismiss();
                    Console.WriteLine("Alert is Dismissed");
                }
                else
                {
                    Console.WriteLine("Alert Action is Indefined");
                }
            }
            catch (NoAlertPresentException NoAlert)
            {
                Console.WriteLine("No Alert is Present");
                Console.WriteLine(NoAlert.StackTrace);
            }
        }
        /* ______________Entering the Value in Textbox_____________________*/
        public static void Enter_Value_EmailUpdate(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";
            string finalData = "";
            try
            {
                string timeStamp = Reports.replace(DateTime.Now.ToString()).Replace("_", "");
                string[] str = TestData.Split('@');
                finalData = str[0] + "_" + timeStamp + "@" + str[1];

                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                ele.Click();
                ele.Clear();
                ele.SendKeys(finalData);
                Assert.IsNotNull(ele);
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, finalData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        public static void JSClick_on(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            String exMsg = "";

            String FlagTestCase = "Pass";

            try
            {
                System.Threading.Thread.Sleep(1000);
                IWebElement ele = null;
                ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                Actions action = new Actions(driver);
                action.MoveToElement(ele);
                action.Build();
                action.Perform();
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", ele);

                if (ele == null)
                {
                    if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                    {
                        HybridLogic.bProceedOnFail = false;
                    }
                    FlagTestCase = "Fail";
                    TestLogic.TestFail++;
                    exMsg = "Element is not present in the DOM";
                }
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, "", "" + "\n" + exMsg, FlagTestCase, RunningTestCase);

            }
        }

        public static void EXITAPPLICATION(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            String exMsg = "";

            String FlagTestCase = "Pass";

            try
            {
                var ele = driver.FindElement(By.XPath(xpath), GlobalWaitTime_int);
                CommonFunctions.highlight(driver, ele);

                ele.Click();

                Assert.IsNotNull(ele);
                Thread.Sleep(3000);
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
            }
            catch (Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }

        public static void SetZoom100()
        {
            // Get DPI setting.
            RegistryKey dpiRegistryKey = Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop\\WindowMetrics");
            int dpi = (int)dpiRegistryKey.GetValue("AppliedDPI");
            // 96 DPI / Smaller / 100%
            int zoomFactor100Percent = 100000;
            Console.WriteLine("dpi:" + dpi);
            switch (dpi)
            {
                case 120: // Medium / 125%
                    zoomFactor100Percent = 80000;
                    break;
                case 144: // Larger / 150%
                    zoomFactor100Percent = 66667;
                    break;
            }
            // Get IE zoom.
            RegistryKey zoomRegistryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Internet Explorer\\Zoom", true);
            currentZoomFactor = (int)zoomRegistryKey.GetValue("ZoomFactor");
            Console.WriteLine("Current Zoom" + currentZoomFactor);

            if (currentZoomFactor != zoomFactor100Percent)
            {
                // Set IE zoom and remember the previous value.
                zoomRegistryKey.SetValue("ZoomFactor", zoomFactor100Percent, RegistryValueKind.DWord);
                m_PreviousZoomFactor = currentZoomFactor;
                Console.WriteLine("Updated currentZoomFactor Zoom" + currentZoomFactor);
            }
        }

        public static void Testconnection(string sBrowserName)
        {
            try
            {
                string connetionString = null;
                //connetionString = "Data Source = JCUATI4\\JCUATCODAT01; Initial Catalog=DBSVY01;Integrated Security=SSPI;"
                //providerName = "System.Data.SqlClient";
                connetionString = "data source=JCUATI4\\JCUATCODAT01;Initial Catalog = DBSVY01; Integrated Security = SSPI";

                SqlDataReader dataReader;
                string sql = null;
                //SqlConnection con = new SqlConnection("Server=JCUATI4\\JCUATCODAT01,Authentication=Windows Authentication, Database=DBSVY01");
                SqlConnection con = new SqlConnection(connetionString);
                con.Open();
                sql = "Select * from DBSVY01.dbo.t_hcop_mevt where hco_mevt_id = 722797";

                SqlCommand command = new SqlCommand(sql, con);
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    Console.WriteLine(dataReader.GetValue(0) + " - " + dataReader.GetValue(1) + " - " + dataReader.GetValue(2));
                }
                dataReader.Close();
                command.Dispose();


                con.Close();
            }
            catch (System.Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
        }


        public static void Testconnection_WST(string sBrowserName)
        {
            try
            {
                var httpClient = new HttpClient();
                var wstDataSyncAPIUrl = ConfigurationManager.AppSettings["WSTDataSyncURL"];
                int hcomevtid = 43540617;
                HttpResponseMessage response = httpClient.PostAsync(string.Format(wstDataSyncAPIUrl, hcomevtid), null).Result;
                Console.WriteLine("Result : "+ response.ToString());

                /*string connetionString = null;
                //connetionString = "Data Source = JCUATI4\\JCUATCODAT01; Initial Catalog=DBSVY01;Integrated Security=SSPI;"
                //providerName = "System.Data.SqlClient";
                connetionString = "data source=JCDEVI4\\JCCODAT01;Initial Catalog = DBSVY01; Integrated Security = SSPI";

                SqlDataReader dataReader;
                string sql = null;
                //SqlConnection con = new SqlConnection("Server=JCUATI4\\JCUATCODAT01,Authentication=Windows Authentication, Database=DBSVY01");
                SqlConnection con = new SqlConnection(connetionString);
                con.Open();
                //sql = "Select * from DBSVY01.dbo.t_hcop_mevt where hco_mevt_id = 43686774";

                string script = System.IO.File.ReadAllText(@"C:\Pathmanaban\ACOSTDTestAutomation\WSTScript.sql");

                SqlCommand command = new SqlCommand(script, con);
                //command.Parameters.Add(new SqlParameter("@hco_mevt_id", "43686774"));

                var result = command.ExecuteNonQuery();
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    Console.WriteLine(dataReader.GetValue(0) + " - " + dataReader.GetValue(1) + " - " + dataReader.GetValue(2));
                }
                dataReader.Close();
                command.Dispose();


                //command.Dispose();


                con.Close();*/
            }
            catch (System.Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
        }

        public static void Pre_Script(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";

            try
            {

                /*string connetionString = null;
                //connetionString = "Data Source = JCUATI4\\JCUATCODAT01; Initial Catalog=DBSVY01;Integrated Security=SSPI;"
                //providerName = "System.Data.SqlClient";
                connetionString = "data source=JCUATI4\\JCUATCODAT01;Initial Catalog = DBSVY01; Integrated Security = SSPI";

                SqlDataReader dataReader;
                string sql = null;
                //SqlConnection con = new SqlConnection("Server=JCUATI4\\JCUATCODAT01,Authentication=Windows Authentication, Database=DBSVY01");
                SqlConnection con = new SqlConnection(connetionString);
                con.Open();
                //sql = "Select * from DBSVY01.dbo.t_hcop_mevt where hco_mevt_id = 43686774";

                string script = System.IO.File.ReadAllText(@"C:\Pathmanaban\ACOSTDTestAutomation\PreScript.sql");

                SqlCommand command = new SqlCommand(script, con);
                command.Parameters.Add(new SqlParameter("@hco_mevt_id", "43686774"));
                command.Parameters.Add(new SqlParameter("@hco_mevt_id", "43686774"));

                var result= command.ExecuteNonQuery();
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    Console.WriteLine(dataReader.GetValue(0) + " - " + dataReader.GetValue(1) + " - " + dataReader.GetValue(2));
                }
                dataReader.Close();
                command.Dispose();


                //command.Dispose();


                con.Close();*/
                string connetionString = null;
                connetionString = "Data Source = JCUATI4\\JCUATCODAT01; Initial Catalog=DBSVY01;Integrated Security=SSPI";
                //providerName = "System.Data.SqlClient";
                //connetionString = "data source=JCDEVI4\\JCDEVCODAT01;Initial Catalog = DBSVY01; Integrated Security = SSPI";

                SqlDataReader dataReader;
                string sql = null;
                //SqlConnection con = new SqlConnection("Server=JCUATI4\\JCUATCODAT01,Authentication=Windows Authentication, Database=DBSVY01");
                SqlConnection con = new SqlConnection(connetionString);
                con.Open();
                //sql = "Select * from DBSVY01.dbo.t_hcop_mevt where hco_mevt_id = 43686774";
                string param1 = ConfigurationManager.AppSettings["param1"];
                string param2 = ConfigurationManager.AppSettings["param2"];
                param2=DateTime.Now.ToString("M/d/yyyy");
                Console.WriteLine("Parameter2 : " + param2);

                string script = System.IO.File.ReadAllText(@"C:\Pathmanaban\ACOSTDTestAutomation\WSTScript.sql");

                SqlCommand command = new SqlCommand(script, con);
                command.Parameters.Add(new SqlParameter("@param1", param1));
                command.Parameters.Add(new SqlParameter("@param2", param2));

                var result = command.ExecuteNonQuery();
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    Console.WriteLine(dataReader.GetValue(0) + " - " + dataReader.GetValue(1) + " - " + dataReader.GetValue(2));
                }
                dataReader.Close();
                command.Dispose();


                //command.Dispose();


                con.Close();
            }
            catch (System.Exception ex)
            {
                if (HybridLogic.sProceedOnFail.ToUpper() == "N" || HybridLogic.sProceedOnFail.ToUpper() == "NO")
                {
                    HybridLogic.bProceedOnFail = false;
                }
                FlagTestCase = "Fail";
                TestLogic.TestFail++;
                exMsg = ex.Message.Replace("width: 1349px; height: 1368px; z-index: 1001;", "");
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
        }


        public void Testconnection_Service1(string browser, string TestData, string TestStepID, string TestStepDesc, string Keyword, string ObjectName, string xpath, string xpath_verification, string RunningTestCase)
        {
            string flag = "";
            string FlagTestCase = "Pass";
            string exMsg = "";



            try
            {
                var httpClient = new HttpClient();
                var wstDataSyncAPIUrl = ConfigurationManager.AppSettings["WSTDataSyncURL"];
                int hcomevtid = 55;
                HttpResponseMessage response = httpClient.PostAsync(string.Format(wstDataSyncAPIUrl, hcomevtid), null).Result;


                //System.Net.Http.HttpResponseMessage res = HttpClient.PostAsync(String.Format(wstDataSyncAPIUrl, hcomevtid), null).Result;

                //Dim wstDataSyncAPIUrl As String = ConfigurationManager.AppSettings("WSTDataSyncURL")
                //Dim response As System.Net.Http.HttpResponseMessage = httpClient.PostAsync(String.Format(wstDataSyncAPIUrl, hcomevtid), Nothing).Result

            }
            catch
            {
            }
            finally
            {
                Console.WriteLine(TestStepID + " - " + TestStepDesc + "\n" + exMsg + " - " + Keyword + " - " + ObjectName + " - " + TestData + " - " + FlagTestCase + " - " + RunningTestCase);
                Reports.Report_TestDataStep(driver, TestStepID, TestStepDesc, Keyword, ObjectName, TestData + "\n" + exMsg, FlagTestCase, RunningTestCase);
            }
           // return true;

        }

    }

}
