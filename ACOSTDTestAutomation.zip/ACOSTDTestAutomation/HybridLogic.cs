﻿using System;
using System.Linq;
using System.Diagnostics;
using System.Data;
using System.Windows.Forms;
using ACOSTDTestAutomation.Utilities;
using ACOSTDTestAutomation.Operations;
using System.Configuration;
using Microsoft.CSharp.RuntimeBinder;
using ACOSTDTestAutomation;

namespace ACOSTDTestAutomation
{
    class HybridLogic
    {
        static int numTotalTestCases = 0;
        public static string sBrowserName = string.Empty;
        public static string sModuleName = string.Empty;
        public static string sModuleDesc = string.Empty;
        public static string sRunningTestCaseName = string.Empty;
        public static string sRunningTestCaseDesc = string.Empty;

        public static string sTestDataID = string.Empty;
        public static string sTestStepID = string.Empty;
        static string sTestStepDesc = string.Empty;
        static string sKeyword = string.Empty;
        static string sDataColumnName = string.Empty;
        static string sDataColumnValue = string.Empty;
        static string sVerification = string.Empty;
        public static string sProceedOnFail = string.Empty;
        public static bool bProceedOnFail = true;
        static bool bObjectFound = false;
        public static string TestCaseFound = string.Empty;

        static string sObject = string.Empty;
        static string sXPathValue = string.Empty;
        static string sXPathValueVerification = string.Empty;

        static string Browser_StartTime;
        static string Browser_EndTime;
        static string TestModule_StartTime;
        static string TestModule_EndTime;
        static string TestCase_StartTime;
        static string TestCase_EndTime;
        static string TestData_StartTime;
        static string TestData_EndTime;

        static DataTable dtTestCases = new DataTable();
        static DataTable dtTestData = new DataTable();
        static DataTable dtTestObjects = new DataTable();

        static Stopwatch stopWatch = new Stopwatch();

        /* ______________Method for running the test logic for all test methods_____________________*/
        public static void HybridMethodNew(string testName)
        {
            try
            {
                string[] module_testcasename = testName.Split(new[] { '_' }, 2);

                DataRow drModule = ACOSTDTestAutomation.TestLogic.dsData.Tables["TestModules"].AsEnumerable()
                                              .Where(a => a.Field<string>("Name").Trim() == module_testcasename[0] &&
                                                     (a.Field<string>("Run").Trim().ToUpper() == "YES" ||
                                                     a.Field<string>("Run").Trim().ToUpper() == "Y" ||
                                                     a.Field<string>("Run").Trim().ToUpper() == "R"))
                                                     .Select(m => m).FirstOrDefault();

                sModuleName = drModule.Field<string>("Name").Trim();

                if (!string.IsNullOrEmpty(sModuleName))
                {
                    dtTestCases = ACOSTDTestAutomation.TestLogic.dsData.Tables["TestCases"];

                    sRunningTestCaseName = dtTestCases.AsEnumerable()
                                            .Where(a => a.Field<string>("Name").Trim() == module_testcasename[1] &&
                                                   (a.Field<string>("Run").Trim().ToUpper() == "YES" ||
                                                    a.Field<string>("Run").Trim().ToUpper() == "Y" ||
                                                    a.Field<string>("Run").Trim().ToUpper() == "R"))
                                            .Select(c => c.Field<string>("Name").Trim()).FirstOrDefault();

                    if (!string.IsNullOrEmpty(sRunningTestCaseName))
                    {
                        sModuleDesc = drModule.Field<string>("Description").Trim();

                        DataTable dtBrowsers = ACOSTDTestAutomation.TestLogic.dsData.Tables["TestBrowsers"];
                        DataTable dtReportSettings = TestLogic.dsData.Tables["TestSettings"];

                        var browserList = getListPostFiltering(dtBrowsers, "Run");

                        Reports.ProjectName = Reports.setReportDetails(dtReportSettings, "ProjectName");
                        Reports.UserReq = Reports.setReportDetails(dtReportSettings, "UserRequested");
                        Reports.TestEnv = Reports.setReportDetails(dtReportSettings, "Environment");
                        Reports.Release1 = Reports.setReportDetails(dtReportSettings, "Release");
                        Reports.ChromeWaitPercentage = Reports.setReportDetails(dtReportSettings, "ChromeWaitPercentage");
                        Reports.FirefoxWaitPercentage = Reports.setReportDetails(dtReportSettings, "FirefoxWaitPercentage");

                        // foreach browser
                        foreach (var browser in browserList)
                        {
                            sProceedOnFail = string.Empty;
                            bProceedOnFail = true;

                            stopWatch.Start();
                            TestCaseFound = "";

                            Browser_StartTime = "";
                            Browser_StartTime = DateTime.Now.ToString();
                            sBrowserName = browser["Name"].ToString().Trim();

                            sRunningTestCaseDesc = dtTestCases.AsEnumerable()
                                                .Where(a => a.Field<string>("Name").Trim() == sRunningTestCaseName &&
                                                       (a.Field<string>("Run").Trim().ToUpper() == "YES" ||
                                                        a.Field<string>("Run").Trim().ToUpper() == "Y" ||
                                                        a.Field<string>("Run").Trim().ToUpper() == "R"))
                                                .Select(c => c.Field<string>("Description").Trim()).FirstOrDefault();

                            TestModule_StartTime = "";
                            TestModule_StartTime = DateTime.Now.ToString();

                            dtTestObjects = ACOSTDTestAutomation.TestLogic.dsData.Tables["TestObjects"];

                            numTotalTestCases++;
                            TestCase_StartTime = "";
                            TestCase_StartTime = DateTime.Now.ToString();
                            
                            TestCaseFound = "found";

                            dtTestData = TestLogic.dsData.Tables["TestData"].AsEnumerable()
                                                            .Where(a => a.Field<string>("TestCaseName").Trim().Equals(sRunningTestCaseName))
                                                            .Select(a => a).CopyToDataTable();

                            var dataList = getListPostFiltering(dtTestData, "Run");

                            // foreach test data
                            foreach (var dataRow in dataList)
                            {
                                TestData_StartTime = DateTime.Now.ToString();
                                sTestDataID = dataRow["ID"].ToString();

                                DataTable dtTestDataDetails = ACOSTDTestAutomation.TestLogic.dsData.Tables["TestDataDetails"].AsEnumerable()
                                                            .Where(a => a.Field<string>("ID").Trim().Equals(sTestDataID.Trim()))
                                                            .Select(a => a).CopyToDataTable();

                                DataTable dtTestCaseSteps = TestLogic.dsData.Tables["TestSteps"].AsEnumerable()
                                                            .Where(a => a.Field<string>("Name").Trim().Equals(sRunningTestCaseName))
                                                            .Select(a => a).CopyToDataTable();

                                var stepsList = getListPostFiltering(dtTestCaseSteps, "Run");

                                // foreach test step
                                foreach (var step in stepsList)
                                {
                                    sTestStepID = step["ID"].ToString().Trim();
                                    sTestStepDesc = step["Description"].ToString().Trim();
                                    sKeyword = step["Keyword"].ToString().ToUpper().Trim();
                                    sObject = step["Object"].ToString().Trim();
                                    sDataColumnName = step["DataColumnName"].ToString().Trim();
                                    sProceedOnFail = step["ProceedOnFail"].ToString().Trim();
                                    sXPathValue = string.Empty;
                                    sXPathValueVerification = string.Empty;
                                    bObjectFound = false;

                                    DataRow[] rows = dtTestDataDetails.Select("Name LIKE '" + step["DataColumnName"].ToString().Trim() + "'");
                                    if (rows != null)
                                    {
                                        if (rows.Count() > 0)
                                        {
                                            switch (rows[0]["Value"].ToString())
                                            {
                                                case "Customer_URL":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["customer_url"];
                                                    break;

                                                case "Username":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["username"];
                                                    break;

                                                case "Password":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["password"];
                                                    break;

                                                case "Employee_URL1":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["employee_url1"];
                                                    break;

                                                case "Employee_URL2":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["employee_url2"];
                                                    break;

                                                case "Employee_URL3":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["employee_url3"];
                                                    break;

                                                case "Employee_URL4":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["employee_url4"];
                                                    break;

                                                case "Employee_URL5":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["employee_url5"];
                                                    break;

                                                case "Employee_URL6":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["employee_url6"];
                                                    break;

                                                case "Employee":
                                                    sDataColumnValue = ConfigurationManager.AppSettings["employee"];
                                                    break;

                                                default:
                                                    sDataColumnValue = rows[0]["Value"].ToString().Trim();
                                                    break;
                                            }
                                        }
                                    }

                                    for (int count = 0; count < dtTestObjects.Rows.Count; count++)
                                    {
                                        if (dtTestObjects.Rows[count]["Name"].ToString().Trim() == sObject)
                                        {
                                            sXPathValue = dtTestObjects.Rows[count]["XPathValue"].ToString();
                                            bObjectFound = true;
                                        }

                                        if (bObjectFound)
                                            break;
                                    }

                                    if (bProceedOnFail)
                                    {
                                        if (bObjectFound == false && sKeyword != "WAIT" && sKeyword != "WAITEQUALLY" && sKeyword != "BROWSER" && sKeyword != "NAVIGATETO" && sKeyword != "SWITCH_TO_NEWTAB" && sKeyword != "CLOSE_BROWSER" && sKeyword != "CLOSE_TAB" && sKeyword != "VERIFYPDF" && sKeyword != "VERIFYNOVALIDATION" && sKeyword != "VERIFY_CLOSEDIALOG")
                                            Reports.Report_TestDataStep(SeleniumActions.driver, sTestStepID, "'" + sObject + "' - object does not exist in the ObjRep sheet '" + sModuleName + "'", sKeyword, sDataColumnName, sDataColumnValue, "Fail", sRunningTestCaseName);

                                        if (sTestStepDesc.Length <= 0)
                                        {
                                            if (step["DataColumnName"].ToString().Trim().Length > 0)
                                                sTestStepDesc = "Performed " + sKeyword + " operation on " + step["Object"].ToString().Trim() + " with " + step["DataColumnName"].ToString().Trim();
                                            else
                                                sTestStepDesc = "Performed " + sKeyword + " operation on " + step["Object"].ToString().Trim();
                                        }

                                        switch (sKeyword)
                                        {
                                            case "BROWSER":
                                                SeleniumActions.InvokeBrowser(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "LOGIN_POPUP":
                                                SeleniumActions.Login_Popup(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "NAVIGATETO":
                                                SeleniumActions.NavigateTo(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "CLICK":
                                                SeleniumActions.Click_on(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "PRINTWINDOW":
                                                SeleniumActions.Print_Window(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "JSCLICK":
                                                SeleniumActions.JSClick_on(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "CLICKTAB":
                                                SeleniumActions.ClickTab_NextLink = getObjectValues(sObject + "1");
                                                SeleniumActions.ClickTab_TabToDisplay = getObjectValues(sObject + "2");

                                                SeleniumActions.Click_Tab(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "CLICKTAB2":
                                                SeleniumActions.ClickTab_NextLink = getObjectValues(sObject + "1");
                                                SeleniumActions.ClickTab_TabToDisplay = getObjectValues(sObject + "2");

                                                SeleniumActions.Click_Tab2(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "CLICKHCO":
                                                SeleniumActions.HCO_ID = getObjectValues(sObject + "1");
                                                SeleniumActions.Click_HCO(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "GETTEXT":
                                                SeleniumActions.Get_Text(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "MOUSE_HOVER":
                                                SeleniumActions.Mouse_Hover(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "WAIT":
                                                SeleniumActions.Wait_For(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "WAITEQUALLY":
                                                SeleniumActions.Wait_ForEqually(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "SELECT":
                                                SeleniumActions.SelectByText(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "SELECTBYVALUE":
                                                SeleniumActions.SelectByValue(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "SELECTBYINDEX":
                                                SeleniumActions.SelectByIndex(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFY":
                                                SeleniumActions.verification_value(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFYELEMENT":
                                                SeleniumActions.Verify_Element(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFYNOTEMPTY":
                                                SeleniumActions.Verification_NotEmpty(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFYLIST":
                                                SeleniumActions.verification_list(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFYNOVALIDATION":
                                                SeleniumActions.verification_NoValidation(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "SERVICE":
                                                SeleniumActions.Pre_Script(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                //SeleniumActions.Testconnection_Service1(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                SeleniumActions.Testconnection_WST(sBrowserName);
                                                break;

                                            case "VERIFYPDF":
                                                //SeleniumActions.verification_PDF(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFYDOCUMENTSLINKS":
                                                SeleniumActions.Verify_DocumentsLinks(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "STORE_DETAILS":
                                                SeleniumActions.Store_Details(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFY_STORED_DETAILS":
                                                SeleniumActions.VerifyStored_Details(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "ENTER":
                                                SeleniumActions.Enter_Value(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;
                                            case "ENTER_EMAIL":
                                                SeleniumActions.Enter_Value_EmailUpdate(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "CLEAR":
                                                SeleniumActions.Clear_Value(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "SORTASCEND":
                                                SeleniumActions.ColumnSortBtn = getObjectValues(sObject + "1");

                                                SeleniumActions.SortColumnAscending(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "ENTER_VALUE_BYTAGNAME":
                                                SeleniumActions.Enter_Value_ByTagName(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "CLICK_ON_LINK":
                                                SeleniumActions.Click_on_link(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFY_SEARCH_LINK":
                                                SeleniumActions.Verifying_search_link(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFY_LEFTNAV":
                                                SeleniumActions.Verify_leftNavigation(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "SWITCH_TO_NEWTAB":
                                                SeleniumActions.SwitchToNewTab(sTestStepID, sTestStepDesc, sKeyword, sRunningTestCaseName);
                                                break;

                                            case "VERIFY_CLOSEDIALOG":
                                                SeleniumActions.Verify_CloseDialog(sTestStepID, sTestStepDesc, sKeyword, sRunningTestCaseName);
                                                break;

                                            case "GET_TOKENS":
                                                SeleniumActions.Get_Tokens(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "VERIFY_TOKENS":
                                                SeleniumActions.Verify_Tokens(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "CLOSE_BROWSER":
                                                SeleniumActions.CloseBrowser(sTestStepID, sTestStepDesc, sKeyword, sRunningTestCaseName);
                                                break;

                                            case "CLOSE_TAB":
                                                SeleniumActions.CloseTab(sTestStepID, sTestStepDesc, sKeyword, sRunningTestCaseName);
                                                break;

                                            case "HIGHLIGHT":
                                                SeleniumActions.highlightUsingXpath(SeleniumActions.driver, sXPathValue, sTestStepID, sTestStepDesc, sKeyword, sRunningTestCaseName);
                                                break;

                                            case "DOWNLOAD_VERIFICATION":
                                                SeleniumActions.Download_Verification(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            case "EXITAPPLICATION":
                                                SeleniumActions.EXITAPPLICATION(sBrowserName, sDataColumnValue, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValue, sXPathValueVerification, sRunningTestCaseName);
                                                break;

                                            default:
                                                Reports.Report_TestDataStep(SeleniumActions.driver, sTestStepID, "'" + sKeyword + "' does not exist, please provide correct Keyword.", sKeyword, sObject, sDataColumnValue, "Fail", sRunningTestCaseName);
                                                break;
                                        }
                                    }
                                    else
                                    {
                                        if (!(sKeyword == "CLOSE_BROWSER"))
                                        {
                                            Reports.Report_TestDataStep(SeleniumActions.driver, sTestStepID, sTestStepDesc, sKeyword, sObject, sXPathValueVerification, "Not Executed", sRunningTestCaseName);
                                        }
                                    }
                                    sDataColumnValue = "";
                                    sTestStepID = "";
                                    sTestStepDesc = "";
                                    sKeyword = "";
                                    sObject = "";
                                    sDataColumnName = "";
                                    sVerification = "";
                                    sProceedOnFail = "";
                                }

                                if (!bProceedOnFail)
                                {
                                    SeleniumActions.CloseBrowser(sTestStepID, sTestStepDesc, sKeyword, sRunningTestCaseName);
                                }

                                TestData_EndTime = DateTime.Now.ToString();
                                Reports.Report_TestData(TestData_StartTime, TestData_EndTime);
                            }

                            TestCase_EndTime = DateTime.Now.ToString();
                            Reports.Report_TestModule(TestCase_StartTime, TestCase_EndTime);

                            TestModule_EndTime = DateTime.Now.ToString();
                            Reports.Report_Browser(TestModule_StartTime, TestModule_EndTime);

                            Browser_EndTime = DateTime.Now.ToString();

                            stopWatch.Stop();
                            TimeSpan ts = stopWatch.Elapsed;
                            string tsr = ts.Hours.ToString("00") + ":" + ts.Minutes.ToString("00") + ":" + ts.Seconds.ToString("00") + "." + ts.Milliseconds.ToString("000");

                            Reports.Report_Summary(Browser_StartTime, Browser_EndTime, tsr);

                            stopWatch.Restart();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Reports.Report_TestDataStep(SeleniumActions.driver, sTestStepID, ex.ToString(), sKeyword, sDataColumnName, sDataColumnValue, "Fail", sRunningTestCaseName);
            }
        }

        /* ______________Filtering the Datasets_____________________*/
        static dynamic getListPostFiltering(DataTable dt, string searchByColumn)
        {
            var filteredList = dt.AsEnumerable().
                                Where(t => t.Field<string>(searchByColumn).Trim().ToUpper() == "YES" || t.Field<string>(searchByColumn).Trim().ToUpper() == "Y" || t.Field<string>(searchByColumn).Trim().ToUpper() == "R");
            return filteredList;
        }

        static string getObjectValues(string object_Name)
        {
            string objectValue = dtTestObjects.AsEnumerable().
                          Where(t => t.Field<string>("Name").ToString().Trim() == object_Name).Select(t => t.Field<string>("XPathValue")).FirstOrDefault();

            return objectValue;
        }

    }
}
