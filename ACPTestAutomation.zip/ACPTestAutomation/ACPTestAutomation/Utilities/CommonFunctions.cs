﻿using ACPTestAutomation.Operations;
using java.awt;
using java.awt.@event;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace ACPTestAutomation.Utilities
{
    class CommonFunctions
    {
        static string SavedFiles = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName + "\\SavedFiles";

        /* ______________Killing the process/Ending the Thread_____________________*/
        public static void KillProcess(string instance)
        {
            foreach (Process clsProcess in Process.GetProcesses())
            {
                if (clsProcess.ProcessName.Equals(instance))
                {
                    clsProcess.Kill();
                }
            }
        }

        /* ______________Dynamic Folder Path of the Project_____________________*/
        public static string FolderPath()
        {
            string Path = Directory.GetCurrentDirectory();
            string[] words = Path.Split('\\');
            Path = "";
            for (int i = 0; i < words.Length - 3; i++)
            {
                Path += words[i] + @"\";
            }

            Path += words[words.Length - 4];
            return Path;
        }

        /* ______________Highlighting the Web Element_____________________*/
        public static void highlight(IWebDriver driver, IWebElement element)
        {
            var jsDriver = (IJavaScriptExecutor)driver;
            string highlightJavascript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color: red"";";
            jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
        }

        public static string SaveAction(string name)
        {
            Robot r = new Robot();

            r.keyPress(KeyEvent.VK_CONTROL);
            Thread.Sleep(2000);
            r.keyPress(KeyEvent.VK_S);

            Thread.Sleep(3000);

            r.keyRelease(KeyEvent.VK_CONTROL);
            r.keyRelease(KeyEvent.VK_S);

            if (!Directory.Exists(SavedFiles))
            {
                Directory.CreateDirectory(SavedFiles);
            }

            SavedFiles = SavedFiles.Replace(@"\\", @"\");

            Thread.Sleep(2000);

            DeleteAllFilesInFolder(SavedFiles);

            Thread.Sleep(2000);
            string fileName = name + "_" + Reports.replace(DateTime.Now.ToString("dd MMM yyyy")) + "_" + Reports.replace(DateTime.Now.ToString("T")) + ".pdf";

            SendKeys.SendWait(@SavedFiles + @"\" + fileName);
            Thread.Sleep(5000);
            SendKeys.SendWait(@"{Enter}");

            return SavedFiles + @"\" + fileName;
        }

        public static string SaveAction_IE(string name)
        {
            Robot r = new Robot();
            r.keyPress(KeyEvent.VK_ESCAPE);
            r.keyRelease(KeyEvent.VK_ESCAPE);

            Thread.Sleep(3000);

            r.keyPress(KeyEvent.VK_CONTROL);
            r.keyPress(KeyEvent.VK_SHIFT);
            r.keyPress(KeyEvent.VK_S);

            Thread.Sleep(1000);

            r.keyRelease(KeyEvent.VK_CONTROL);
            r.keyRelease(KeyEvent.VK_SHIFT);
            r.keyRelease(KeyEvent.VK_S);

            if (!Directory.Exists(SavedFiles))
            {
                Directory.CreateDirectory(SavedFiles);
            }

            SavedFiles = SavedFiles.Replace(@"\\", @"\");

            Thread.Sleep(3000);

            DeleteAllFilesInFolder(SavedFiles);

            Thread.Sleep(3000);
            string fileName = name + "_" + Reports.replace(DateTime.Now.ToString("dd MMM yyyy")) + "_" + Reports.replace(DateTime.Now.ToString("T")) + ".pdf";

            SendKeys.SendWait(@SavedFiles + @"\" + fileName);
            Thread.Sleep(5000);
            SendKeys.SendWait(@"{Enter}");

            return SavedFiles + @"\" + fileName;
        }

        public static void DeleteAllFilesInFolder(string folderPath)
        {
            DirectoryInfo di = new DirectoryInfo(folderPath);

            foreach (FileInfo file in di.GetFiles())
            {
                file.Delete();
            }
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                dir.Delete(true);
            }
        }

        public static bool GetCommandLineargs()
        {
            bool flag = false;
            try
            {
                string[] args = Environment.GetCommandLineArgs();
                string FinalCategory = "";

                if (args.Length > 0)
                {
                    foreach (string str in args)
                    {
                        if (str.Contains("TestCaseFilter"))
                        {
                            //Console.WriteLine("\ncategory fetched " + str);
                            FinalCategory = str;
                            break;
                        }
                    }

                    string[] category = FinalCategory.Split('=');

                    if (category[1] == "PatchTesting")
                    {
                        flag = true;
                    }
                }
            }
            catch { }
            return flag;
        }

    }
}
